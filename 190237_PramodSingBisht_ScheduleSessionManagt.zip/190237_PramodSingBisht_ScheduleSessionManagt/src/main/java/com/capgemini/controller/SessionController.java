package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.SessionNotFoundException;
import com.capgemini.model.Session;
import com.capgemini.service.SessionService;
@RestController
@RequestMapping(value="sessions")
public class SessionController {

	@Autowired
	private SessionService service;
	
	// http://localhost:9090/sessions/
	@RequestMapping(value="/", method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Session> getAllStudents(){
		List<Session> list = service.findAllSession();
		return list;
	}
	// http://localhost:9090/sessions/102
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Session getSessionById(@PathVariable("id")int sessionId){
		Session session = service.findSessionById(sessionId);
		if(session==null){
			throw new SessionNotFoundException("session not found"+sessionId);
		}
		return session;
	}
	// http://localhost:9090/sessions/
	@RequestMapping(value="/", method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public void addSession(@RequestBody Session session1){
		service.addSession(session1);
	}
	//http://localhost:9090/sessions/101/
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	public void deleteStudentById(@PathVariable("id")int sessionId){
		Session session = service.findSessionById(sessionId);
		service.removeSession(session);
	}
	// http://localhost:9090/sessions/
	@RequestMapping(value="/", method=RequestMethod.PUT)
	public void updateStudent(@RequestBody Session session){
		service.modifySession(session);
	}
	@ResponseStatus(value=HttpStatus.BAD_REQUEST,reason="Id not present")
    @ExceptionHandler({SessionNotFoundException.class})
    public void handleException() {
        
    }
}
