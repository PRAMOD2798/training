package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Session;


public interface SessionDao {

	public abstract void addSession(Session session);
	public abstract void updateSession(Session session);
	public abstract void deleteSession(Session session);
	public abstract List<Session> ViewAllSession();
	public abstract void commitTransaction();
	public abstract Session getSessionById(int id);
	public abstract void beginTransaction();
	
}
