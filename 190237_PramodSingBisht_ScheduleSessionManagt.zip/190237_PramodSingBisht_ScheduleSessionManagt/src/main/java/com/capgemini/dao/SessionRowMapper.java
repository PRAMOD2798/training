package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.model.Session;



public class SessionRowMapper implements RowMapper<Session> {
	public Session mapRow(ResultSet rs, int arg1) throws SQLException {
		int id = rs.getInt("id");
		//int id = rs.getInt(1);
		String name = rs.getString("name");
		//String name = rs.getString(2);
		int duration=rs.getInt("duration");
		String faculty=rs.getString("faculty");
		String mode=rs.getString("mode");
		Session s = new Session();
		s.setId(id);
		s.setName(name);
		s.setDuration(duration);
		s.setFaculty(faculty);
		s.setMode(mode);
		return s;
	}
}
