package com.capgemini.exception;

public class SessionNotFoundException extends RuntimeException            
{

	public SessionNotFoundException(String msg){
		 super(msg);
	}
	
}
