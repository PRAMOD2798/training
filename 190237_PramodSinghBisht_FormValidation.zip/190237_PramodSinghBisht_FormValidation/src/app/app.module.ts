import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { formComponent } from './form.component';
import { ReactiveFormsModule } from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

const appRoutes:Routes=
[
    {path:"",redirectTo:"/validationform",pathMatch:"full"},
    {path:"validationform", component: formComponent} 
]

@NgModule({
  declarations: [
    AppComponent,formComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
