import { Model } from './models';
import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'
@Component({
  selector: 'form-app',
  templateUrl: 'form.component.html'
})
export class formComponent {
  data: Model = { name: "", address: "", pincode: "", status: "INVALID" };

  registerForm = new FormGroup(
    {
      Name: new FormControl(null,[Validators.required,
        Validators.pattern("[a-zA-Z]+")]),

      Address: new FormControl(null, Validators.required),

      Pincode: new FormControl(null, [Validators.required,
      Validators.pattern("[0-9]{6}")])
    }
  );

  onSubmit(registerForm: FormGroup) {
    console.log(this.registerForm.value);
    this.data.name = this.registerForm.controls['Name'].value;

    this.data.address = this.registerForm.controls['Address'].value;
    this.data.pincode = this.registerForm.controls['Pincode'].value;
    this.data.status = "VALID";
  }
}