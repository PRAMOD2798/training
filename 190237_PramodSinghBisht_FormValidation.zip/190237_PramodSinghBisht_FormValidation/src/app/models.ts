export interface Model{
    name:string;
    address:string;
    pincode:string;
    status:string;
}