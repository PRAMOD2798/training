package com.capgemini.controller;

import java.util.List;

import org.aspectj.bridge.MessageWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.SessionNotFoundException;
import com.capgemini.model.Session;
import com.capgemini.service.SessionService;

@RestController
@RequestMapping(value="Sessions")
public class SessionRestController {
	@Autowired
	private SessionService service;
	@RequestMapping(value="/hello", method=RequestMethod.GET)
	public String helloWorld(){
		return "Hello Class From REST service";
	}
	@RequestMapping(value="/", method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Session> getAllSessions(){
		List<Session> list = service.findAllSessions();
		return list;
	}
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Session getSessionById(@PathVariable("id")int SessionId){
		
		Session Session = service.findSessionById(SessionId);
	if(Session == null){
		throw new SessionNotFoundException("Session nOT Found Exception" + SessionId);
		}
		return Session;
	}
	@RequestMapping(value="/", method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public void addSession(@RequestBody Session Session){
		service.addSession(Session);
	}
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	public void deleteSessionById(@PathVariable("id")int SessionId){
		Session Session = service.findSessionById(SessionId);
		service.removeSession(Session);
	}
	@RequestMapping(value="/", method=RequestMethod.PUT)
	public void updateSession(@RequestBody Session Session){
		service.updateSession(Session);
	}
	@ResponseStatus(value=HttpStatus.BAD_REQUEST,reason="Id not present")
  @ExceptionHandler({SessionNotFoundException.class})
	public void handleException() {
        
    }
	}
