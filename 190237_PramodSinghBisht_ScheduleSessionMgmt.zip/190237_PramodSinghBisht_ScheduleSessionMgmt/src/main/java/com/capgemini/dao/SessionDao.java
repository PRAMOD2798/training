package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Session;

public interface SessionDao {

	public abstract Session getSessionById(int id);
	
	public abstract List<Session> getAllSessions();

	public abstract void addSession(Session Session);

	public abstract void removeSession(Session Session);

	public abstract void updateSession(Session Session);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}