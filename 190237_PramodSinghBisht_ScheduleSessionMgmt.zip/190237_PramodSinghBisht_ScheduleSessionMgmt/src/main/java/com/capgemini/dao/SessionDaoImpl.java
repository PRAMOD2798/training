package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.model.Session;
@Repository
public class SessionDaoImpl implements SessionDao {
	private EntityManager entityManager;

	public SessionDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public List<Session> getAllSessions() {
		String query = "From SessionTab";
		TypedQuery<Session> tquery = entityManager.createQuery(query, Session.class);
		List<Session> list = tquery.getResultList();
		return list;
	}
	@Override
	public Session getSessionById(int id) {
		Session Session = entityManager.find(Session.class, id);
		return Session;
	}
	@Override
	public void addSession(Session Session) {
		entityManager.persist(Session);
	}
	@Override
	public void removeSession(Session Session) {
		Session = entityManager.find(Session.class, Session.getId());
		entityManager.remove(Session);
	}
	@Override
	public void updateSession(Session Session) {
		entityManager.merge(Session);
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	
}
