package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.model.Session;


public class SessionRowMapper implements RowMapper<Session> {
	@Override
	public Session mapRow(ResultSet rs, int arg1) throws SQLException {
		//int id = rs.getInt("id");
		//int id = rs.getInt(1);
		String name = rs.getString("name");
		//String name = rs.getString(2);
		String faculty = rs.getString("faculty");
		int duration = rs.getInt("duration");
		String mode= rs.getString("mode");
		Session s = new Session();
		//s.setId(id);
		s.setName(name);
		s.setFaculty(faculty);
		s.setDuration(duration);
		s.setMode(mode);
		return s;
	}
}
