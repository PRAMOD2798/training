package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Session;

public interface SessionService {

	public abstract void addSession(Session Session);

	public abstract void updateSession(Session Session);

	public abstract void removeSession(Session Session);

	public abstract Session findSessionById(int id);
	
	public abstract List<Session> findAllSessions();

}