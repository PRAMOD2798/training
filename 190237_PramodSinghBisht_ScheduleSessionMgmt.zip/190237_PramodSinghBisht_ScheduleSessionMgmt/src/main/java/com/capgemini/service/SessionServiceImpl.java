package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.SessionDao;
import com.capgemini.model.Session;
@Service
public class SessionServiceImpl implements SessionService {
	@Autowired
	private SessionDao dao;


	@Override
	public void addSession(Session Session) {
		dao.beginTransaction();
		dao.addSession(Session);
//		dao.commitTransaction();
	}
	
	@Override
	public void updateSession(Session Session) {
		dao.beginTransaction();
		dao.updateSession(Session);
		dao.commitTransaction();
	}
	
	@Override
	public void removeSession(Session Session) {
		dao.beginTransaction();
		dao.removeSession(Session);
		dao.commitTransaction();
	}
	
	@Override
	public Session findSessionById(int id) {
		Session Session  = dao.getSessionById(id);
		return Session;
	}

	@Override
	public List<Session> findAllSessions() {
		return dao.getAllSessions();
	}
}
