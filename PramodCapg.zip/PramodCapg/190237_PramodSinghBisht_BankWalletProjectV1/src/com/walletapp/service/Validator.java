package com.walletapp.service;

public interface Validator {
	String accountNamePattern = "^[a-zA-Z]+$";
	String emailPattern = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[com|in]{2,3}$";
	String phoneNumberPattern = "(0/91)?[7-9][0-9]{9}";
	String amountPattern = "\\d+\\.?\\d+";
	String accountNumberPattern = "[1-9]+";

	public static boolean validateData(String data, String pattern) {
		return data.matches(pattern);
	}
}
