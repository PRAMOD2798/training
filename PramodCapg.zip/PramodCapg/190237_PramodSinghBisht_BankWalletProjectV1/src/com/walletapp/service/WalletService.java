package com.walletapp.service;

import com.walletapp.model.WalletAccount;

public interface WalletService {
	public boolean addAccount(WalletAccount wa);

	public double showBalance(int accountNumber);

	public double depositMoney(int accountNumber, double money);

	public double transferMoney(int accountNumberFrom, int accountNumberTo, double money);

	public WalletAccount withDrawMoney(int accountNumber, double amountWithdraw);
	
	public String[] showTransaction(int accountNumber);
}
