package com.walletapp.service;

import com.walletapp.dao.WalletDao;
import com.walletapp.dao.WalletDaoImpl;
import com.walletapp.model.WalletAccount;

public class WalletServiceImpl implements WalletService {

	WalletDao dao = new WalletDaoImpl();

	@Override
	public boolean addAccount(WalletAccount wa) {
		boolean result = dao.createAccount(wa);
		return result;
	}

	@Override
	public double showBalance(int accountNumber) {
		double balance = dao.readBalance(accountNumber);
		return balance;
	}

	@Override
	public double depositMoney(int accountNumber, double money) {
		double newBalance = dao.updateMoney(accountNumber, money);
		return newBalance;
	}

	@Override
	public double transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		double transferamount = dao.transferMoney(accountNumberFrom, accountNumberTo, money);
		return transferamount;
	}

	@Override
	public WalletAccount withDrawMoney(int accountNumber, double amountWithdraw) {
		return dao.deleteMoney(accountNumber, amountWithdraw);
	}

	@Override
	public String[] showTransaction(int accountNumber) {
		String[] transaction = dao.readTransaction(accountNumber);
		return transaction;
	}
}
