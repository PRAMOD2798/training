package com.walletapp.exception;

public class WalletAppException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public WalletAppException(Exception e, String msg) {
		super(msg, e);
	}
}
