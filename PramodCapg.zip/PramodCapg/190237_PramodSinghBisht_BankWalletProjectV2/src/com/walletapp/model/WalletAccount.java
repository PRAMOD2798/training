package com.walletapp.model;

public class WalletAccount {
	public int accountNumber = 0;
	private String accountName = "", email = "";
	private double accountBalance = 0.0;
	private long mobileNumber = 0;

	public WalletAccount() {

	}

	public WalletAccount(String accountName, String email, long mobileNumber) {
		super();
		this.accountName = accountName;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WalletAccount [accountName=").append(accountName).append(", email=").append(email)
				.append(", accountBalance=").append(accountBalance).append(", mobileNumber=").append(mobileNumber)
				.append("]");
		return builder.toString();
	}
}
