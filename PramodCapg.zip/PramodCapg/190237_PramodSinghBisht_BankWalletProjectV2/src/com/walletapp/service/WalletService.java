package com.walletapp.service;

import java.util.List;

import com.walletapp.model.WalletAccount;

public interface WalletService {
	public boolean addAccount(WalletAccount wa);

	public double showBalance(int accountNumber);

	public int depositMoney(int accountNumber, double money);

	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money);

	public int withDrawMoney(int accountNumber, double amountWithdraw);
	
	public List<String> showTransaction(int accountNumber);
}
