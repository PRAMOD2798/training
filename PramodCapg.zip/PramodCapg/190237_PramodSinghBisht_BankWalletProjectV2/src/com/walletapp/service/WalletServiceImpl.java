package com.walletapp.service;

import java.util.ArrayList;
import java.util.List;

import com.walletapp.dao.WalletDao;
import com.walletapp.dao.WalletDaoImpl;
import com.walletapp.model.WalletAccount;

public class WalletServiceImpl implements WalletService {

	WalletDao dao = new WalletDaoImpl();

	@Override
	public boolean addAccount(WalletAccount wa) {
		boolean result = dao.createAccount(wa);
		return result;
	}

	@Override
	public double showBalance(int accountNumber) {
		double balance = dao.readBalance(accountNumber);
		return balance;
	}

	@Override
	public int depositMoney(int accountNumber, double money) {
		int newBalance = dao.updateMoney(accountNumber, money);
		return newBalance;
	}

	@Override
	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		int transferamount = dao.transferMoney(accountNumberFrom, accountNumberTo, money);
		return transferamount;
	}

	@Override
	public int withDrawMoney(int accountNumber, double amountWithdraw) {
		return dao.deleteMoney(accountNumber, amountWithdraw);
	}

	@Override
	public List<String> showTransaction(int accountNumber) {
		List<String> transaction = new ArrayList<String>();
		transaction=dao.readTransaction(accountNumber);
		return transaction;
	}
}
