package lab1;
import java.util.*;
public class CheckNumber 
{
	public  boolean Check(int n)
	{
		int x=0,y=0,e=0;
		boolean ral=true;
		while(n!=0)
		{
			x=n%10;
			y=n/10;
			e=y%10;
			if(x>e)
			{
				ral=true;
			}
			else
			{
				ral=false;
				break;
			}
			n=y;
		}
		return ral;
	}
		
		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Number");
			int n=sc.nextInt();
			CheckNumber g=new CheckNumber();
			boolean f=g.Check(n);
			if(f==true)
			{
				System.out.println("Number is Increasing");
			}
			else if(f==false)
			{
				System.out.println("Number is not Increasing");
			}
			

		}
}
