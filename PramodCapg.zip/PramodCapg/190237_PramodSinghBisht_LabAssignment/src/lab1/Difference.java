package lab1;
import java.util.*;
public class Difference 
{
	public static int calculateDifference(int n)
	{
		int sq=0;
		int sum=0;
		int sumsq=0;
		for(int i=1;i<=n;i++)
		{
			sq=sq+(i*i);
			sum=sum+i;
		}
		sumsq=sum*sum;
		
		 return sq-sumsq;
		
	}
	

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit");
		int n=sc.nextInt();
		int r=calculateDifference(n);
		System.out.println("Difference"+r);
		
		
	}

}
