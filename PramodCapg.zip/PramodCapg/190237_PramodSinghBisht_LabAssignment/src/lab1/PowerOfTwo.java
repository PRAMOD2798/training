package lab1;
import java.util.*;

public class PowerOfTwo
{
	public boolean Check(int n)
	{
		if(n%2==0)
		{	
			while(n>2)
			{
			n=n/2;
			}
			
			if(n==2)
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	public static void main(String args[])
	{
		System.out.println("enter the number");
		Scanner sc = new Scanner(System.in);
		int numb =sc.nextInt();
		PowerOfTwo pt = new PowerOfTwo();
		boolean result= pt.Check(numb);
		System.out.println("result is "+result);
	}
}
