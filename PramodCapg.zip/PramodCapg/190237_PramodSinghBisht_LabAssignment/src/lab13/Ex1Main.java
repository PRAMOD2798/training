package lab13;



public class Ex1Main 
{
  public static void main(String argc[])
  { 
	 Power p=(int x,int y) -> {return (int) Math.pow(x,y);};
	 System.out.println("Result:"+p.power(3, 3));
  }



}
