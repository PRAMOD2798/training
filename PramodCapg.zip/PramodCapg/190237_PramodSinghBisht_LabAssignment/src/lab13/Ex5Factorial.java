package lab13;

interface NewInterface{
	void print();
}
public class Ex5Factorial 
{    
	int fact=1;
	int num=5;
	public void fact()
	{
		for(int i=1;i<=5;i++)
		{
			fact=fact*i;
		}
		System.out.println("Fact:="+fact);
	}
	
	public static void main(String argc[])
	{
		Ex5Factorial i=new Ex5Factorial ();
		NewInterface pr=i::fact;
		pr.print();
	}
  
    
 
	
}
