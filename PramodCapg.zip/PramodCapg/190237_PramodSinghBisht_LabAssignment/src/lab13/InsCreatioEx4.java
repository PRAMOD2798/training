package lab13;


interface Printable{
	void print();
}
public class InsCreatioEx4 
{
	 int id;
	 String name;
	 
	 public InsCreatioEx4 (){
		 
	 }
	 
	 public void something()
	 {
		 System.out.println("say: Hello");
	 }
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {
		
		InsCreatioEx4 i=new InsCreatioEx4 ();
		Printable pr=i::something;
		pr.print();

	}

}
