package lab13;

public interface Power 
{
   public int power(int x,int y);
}
