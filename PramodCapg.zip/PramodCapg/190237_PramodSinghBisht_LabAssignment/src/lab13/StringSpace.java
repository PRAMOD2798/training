package lab13;

public class StringSpace 
{
 public static void main(String argc[])
 {
	 StringSpaceI str=(s)-> s.replace(""," ").trim();
	 System.out.println("Result:" +str.space("Pramod"));
	
 }
}
