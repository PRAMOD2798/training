package lab13;

public interface StringSpaceI
{
  public String space(String s);
}
