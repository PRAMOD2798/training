package lab13;

public class UserPass 
{
	public static void main(String argc[]){
    UserPassI result=(str1,str2)->str1.equals("Pramod")&&str2.equals("hello");
	System.out.println("Result "+result.validate("Pramod","hello"));	 
 }
}
