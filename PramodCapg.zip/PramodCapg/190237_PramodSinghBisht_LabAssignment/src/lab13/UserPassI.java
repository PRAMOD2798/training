package lab13;

public interface UserPassI 
{
 public boolean validate(String user,String Pass);
}
