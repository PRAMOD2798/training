package lab14.com.cg.eis.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import lab14.com.cg.eis.bean.Employee;

public class ServiceImpl implements Services
{

	private static List<Employee> list=new ArrayList<>();
	public boolean addEmployee(Employee employee)
	{
		boolean result=list.add(employee);
		return result;
	}

public String insuranceSchemeheck(double salary, String designation) 
   {
	if(salary>5000 &&salary<20000 && designation.equalsIgnoreCase("System Associate") )
	{
	return "Scheme C";
	}
	else if(salary>=20000 &&salary<40000 && designation.equalsIgnoreCase("Programmer") )
	{
		return "Scheme B";
	}
	else if(salary>=40000 && designation.equalsIgnoreCase("Manager") )
	{
		return "Scheme A";
	}
	else if(salary<5000 && designation.equalsIgnoreCase("Clerk"))
	{
		return "No Schema";

	}
	return " wrong";
	}
	
	public void getEmployee(int employeeId) 
	{
		Iterator<Employee> itr=list.iterator();
		while(itr.hasNext())
		{
			Employee emp=itr.next();
			if(emp.getEmoployeeId()==employeeId)
			{
				System.out.println(emp);
				break;
		    }
		
	}

	
	
	
     }
	}
