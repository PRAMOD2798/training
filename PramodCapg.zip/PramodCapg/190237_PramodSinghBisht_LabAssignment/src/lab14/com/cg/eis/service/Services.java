package lab14.com.cg.eis.service;

import lab14.com.cg.eis.bean.Employee;

public interface Services 
{
	  public boolean addEmployee(Employee employee);
	  public void getEmployee(int employeeId);
	  public String insuranceSchemeheck(double salary,String designation);
	   
}
