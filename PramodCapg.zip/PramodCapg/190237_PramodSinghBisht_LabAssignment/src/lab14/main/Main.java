package lab14.main;

import java.util.Scanner;

import lab14.com.cg.eis.bean.Employee;
import lab14.com.cg.eis.service.ServiceImpl;
import lab14.com.cg.eis.service.Services;
public class Main 
{
public static void main(String argc[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("**********Welcome**********");
	double sal=0.0;
	int id=0;
	String des="";
	String name="";
	 boolean flag=true;
	 while(flag)
		 {
		    System.out.println("1.Add Employee \n2.Check Schema Employee\n3.Get Employee");
			System.out.println("Enter your Choice:");
			int ch=sc.nextInt();
			 Services service=new ServiceImpl();
		 	switch(ch)
		 
		 	{
		 	case 1:
		 		System.out.println("Enter EmployeeId:");
		 		 id=sc.nextInt();
		 		System.out.println("Enter Employee Name:");
		 		 name=sc.next();
		 		System.out.println("Enter Employee Salary:");
		 		 sal=sc.nextDouble();
		 		System.out.println("Enter Employee designation:");
		 		des=sc.next();
		 		Employee emp=new Employee(id,name,sal,des); 
		
		 		boolean result=service.addEmployee(emp);
		 		if(result)
		 		{
		 			System.out.println(" Employee added with"+emp.getEmoployeeId());
		 		}
		 		else{
		 			System.out.println(" Problem Occure while adding Employee");
		 		}
		 		break;
	 case 2:
		 System.out.println("Enter salary");
		  sal=sc.nextInt();
		  System.out.println("Enter Employee designation:");
	 	  des=sc.next();
	 	  String s=service.insuranceSchemeheck(sal, des);
	 	 System.out.println("Scheme for employee "+s);
	 	 break;
	 case 3:
		 System.out.println("Enter Employee id:");
		  id=sc.nextInt();
		  service.getEmployee(id);
		  break;
		  default:
			  System.out.println("Wrong choice! please try again");
		 
	 }
		 
	
	}
}
}
