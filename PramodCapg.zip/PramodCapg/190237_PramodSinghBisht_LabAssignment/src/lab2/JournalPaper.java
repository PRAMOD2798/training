package lab2;

public class JournalPaper extends WrittenItem{

	public JournalPaper(int id1, String title, String author2, int noCopies,int publishedYear) {
		super(id1, title, author2, noCopies);
		this.publishedYear=publishedYear;
	}

	private int publishedYear;

	public void checkIn(int bookId) {
		
	}


	public void checkOut(int bookId) {
		
	}

	
	public Item addItem(int id1, String title, String author, int noCopies) {
		return null;
	}
	public void print() {
		
	}
	
	
}
