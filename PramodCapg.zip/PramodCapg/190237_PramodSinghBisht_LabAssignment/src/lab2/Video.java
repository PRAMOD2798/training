package lab2;

public class Video extends MediaItem{
	
	public Video(int bookId, String title, int noCopies, int runtime) {
		super(bookId, title, noCopies, runtime);
	
	}
	private String director;
	private String videogenre;
	private int yor;
	
	public void checkIn(int bookId) {
		
		
	}
	
	public void checkOut(int bookId) {
		
		
	}
	
	public Item addItem(int id1, String title, String author, int noCopies) {
	
		return null;
	}
	public void print() {

		
		
	}


}
