package lab3;
import java.util.*;

public class ReverseAndSort 
{
	public int[] reversesort(int ar[])
	
	{

	    for(int i=0;i<ar.length/2;i++)
	    {
	    	int temp=0;
	    	temp=ar[i];
	    	ar[i]=ar[ar.length-i-1];
	    	ar[ar.length-i-1]=temp;
	    	
	    }
	    
	    return ar;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
	   
	    System.out.println("enter limit");
	    int n=sc.nextInt();
	    int[] ar=new int[n];
	    
	   
	    for(int i=0;i<n;i++)
	    {
	    	ar[i]=sc.nextInt();
	    }
	    ReverseAndSort b=new ReverseAndSort();
		b.reversesort(ar);
		System.out.println("Array After Reversing");
		for(int i=0;i<n;i++)
		System.out.println(ar[i]);
		System.out.println("Array After sorting");
		Arrays.sort(ar);
		for(int i=0;i<n;i++)
		System.out.println(ar[i]);
	}
}
