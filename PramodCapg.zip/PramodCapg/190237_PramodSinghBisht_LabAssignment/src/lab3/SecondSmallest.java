package lab3;
import java.util.*;

public class SecondSmallest {
	
	public  int[] SecondSmallest(int ar[],int l)
	{  int temp = 0; 
		for(int j=0;j<l;j++)
		{
			for(int k=j+1;k<l;k++)
			{
				
				if(ar[j]>ar[j+1])
				{
					
					ar[j]=temp;
					ar[j+1]=ar[j];
					temp=ar[j+1];
				}
				
			}
		}
		return ar;
		
	}

	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit of array");
		int n=sc.nextInt();
		int ar[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			ar[i]=sc.nextInt();
		}
		
		SecondSmallest s=new SecondSmallest();
		
		s.SecondSmallest(ar,n);
		
		System.out.println("Second Smallest number:"+ar[1]);
		
	}

	
}
