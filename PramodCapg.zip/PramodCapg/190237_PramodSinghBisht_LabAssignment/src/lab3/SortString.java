package lab3;
import java.util.*;

public class SortString{
    public String[] sortmethod(String[] s2)
    {
    	Arrays.sort(s2);
    	int div=s2.length/2;
    	if(s2.length%2!=0)
    	{
    		for(int i=0;i<(div+1);i++)
    		{
    			s2[i]=s2[i].toString().toUpperCase();
    		}
    	}
    	else 
    	{
    		for(int i=0;i<div;i++)
    		{
    			s2[i]=s2[i].toString().toUpperCase();
    		}
    	}
    	for(int i=div+1;i<s2.length;i++)
		{
			s2[i]=s2[i].toString().toLowerCase();
		}
    	return s2;
    }
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
	    String[] s2;
	    System.out.println("Enter limit");
	  
	    int n=sc.nextInt();
	     s2=new String[n];
	    for(int i=0;i<n;i++)
	    {
	    	s2[i]=sc.next();
	    }
	    SortString b=new SortString();
		b.sortmethod(s2);
		for(int r=0;r<s2.length;r++)
		System.out.println(s2[r]);

	}
	

}
