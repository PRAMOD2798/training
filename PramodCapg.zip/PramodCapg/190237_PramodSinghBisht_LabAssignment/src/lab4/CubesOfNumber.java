package lab4;

import java.util.Scanner;

import lab1.CheckNumber;

public class CubesOfNumber 
{
	public  static int Check(int n)
	{
		int x=0,e=0;
		int sumq=0;
		while(n!=0)
		{
			x=n%10;
			sumq=sumq+(x*x*x);
			e=n/10;
		
			n=e;
		}
		return sumq;
	}
		
		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the number");
			int n=sc.nextInt();
			System.out.println("Sum of Digit Cubes"+""+Check(n));
			
			
			
			

		}
}
