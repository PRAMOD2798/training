package lab5;

public class AgeException extends Exception
{
 	private int age;
 	public AgeException(int age)
 	{
 		this.age=age;
 	}
 	public String toString()
 	{
 		return "Invalid age"+age;
 	}
 	
}
