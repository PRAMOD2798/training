package lab5;

import java.util.Scanner;

public class FSeries 
{
public static void main(String argc[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Limit");
	int n=sc.nextInt();
	int a=0,b=0,c=1;
	for(int i=1;i<=n;i++)
	{
		 a=b;
		 b=c;
		 c=a+b;
		
	}
	 System.out.println(a);
}
}
