package lab5;

import java.util.Scanner;

public class FibonacciRecursion 
{

	private static int fun(int n)
	{
		if(n==0)
		{
			return 0;
		}
		if(n==1)
		{
			return 1;
		}
		return fun(n-1)+fun(n-2);
	}
	public static void main(String argc[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Limit");
	int n=sc.nextInt();
	fun(n);
		System.out.println(fun(n));	
	}

}
