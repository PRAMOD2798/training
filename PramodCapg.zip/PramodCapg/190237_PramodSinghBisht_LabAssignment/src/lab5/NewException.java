package lab5;

public class NewException extends Exception
{
	private int n;
 	public NewException (int n)
 	{
 		this.n=n;
 	}
 	public String toString()
 	{
 		return "Invalid "+n;
 	}
}
