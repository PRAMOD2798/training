package lab5;

import java.util.Scanner;

public class Prime 
{
public static boolean checkPrime(int n)
	{
	if(n<=1)
	
	return false;
	for(int i=2;i<n;i++)
		if(n%i==0)
			return false;
	return true;
	
	}
   public static void isPrime(int n)
   {
	   for(int i=2;i<=n;i++){
		   if(checkPrime(i))
				   
			   System.out.println(" "+i);
				   }
   }
public static void main(String argc[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the limit:");
	int n=sc.nextInt();
	isPrime(n);
	}
}
