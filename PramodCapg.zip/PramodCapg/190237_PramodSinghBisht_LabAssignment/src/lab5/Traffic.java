package lab5;
import java.util.*;
public class Traffic
{
   public static void method(int n) throws NewException
   
   {
	if(n==1)
	{
		System.out.print("Stop");
	}
	else if(n==2)
	{
		System.out.print("Ready");
	}
	else if(n==3){
	System.out.print("Go");
	}
	else
	{
		NewException ne=new NewException(n);
		throw ne;
	}
   }
   
	
	public static void main(String argc[])
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("1.Red:");
			System.out.println("2.yellow:");
			System.out.println("3.Green:");
			int n=sc.nextInt();
			method(n);
		}
		catch(NewException e)
		{
			System.out.print(e);
		}
		catch(Exception e)
		{
			System.out.print("Problem");
		}
		
	}
}
