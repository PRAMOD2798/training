package lab5;

import java.util.Scanner;
public class ValidateName 
{
public static void validate(String fname,String lname) throws ValidateNameException
{
	if(fname.equals("") || lname.equals(""))
	{
		ValidateNameException v=new ValidateNameException(fname,lname);
		throw v;
	}
	else
		System.out.println("Valid User");
}
public static void main(String argc[])
{
	Scanner sc=new Scanner(System.in);
	try
	{
		System.out.println("Enter your first name:");
		String str1=sc.nextLine();

		System.out.println("Enter your LastName name:");
		String str2=sc.nextLine();
		sc.close();
		
		validate(str1,str2);
	}
	catch(ValidateNameException e)
	{
		System.out.print(e);
	}
	catch(Exception r)
	{
		System.out.print("Problem");
	}
	
}
}
