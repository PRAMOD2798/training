package lab5;

public class ValidateNameException extends Exception
{
	private String str1;
	private String str2;
 	public   ValidateNameException (String str1,String str2)
 	{
 		this.str1=str1;
 		this.str2=str2;
 	}
 	public String toString()
 	{
 		
 		return "Invalid User FirstName And LastName Required";
 	}
}
