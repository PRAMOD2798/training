package lab5.com.cg.eis.exception;

public class CheckSalaryException extends Exception
{
	private int salary;
 	public CheckSalaryException(int salary)
 	{
 		this.salary=salary;
 	}
 	public String toString()
 	{
 		return "Salary is less than 3000";
 	}
}
