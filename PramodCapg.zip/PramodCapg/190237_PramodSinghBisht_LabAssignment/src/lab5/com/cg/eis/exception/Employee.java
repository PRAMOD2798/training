package lab5.com.cg.eis.exception;

import java.util.Scanner;

public class Employee 
{
	static void checkSalary(int salary) throws CheckSalaryException
	{
		if(salary>3000){
			System.out.println("Salary greater than 3000");
		}
		else
		{
			CheckSalaryException  a=new CheckSalaryException (salary);
			throw a;
		}
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
	
		try{
			System.out.println("Enter the Salary");
			int salary=sc.nextInt();
			checkSalary(salary);
		}
		catch(CheckSalaryException r){
			System.out.println(r);
		}
        catch(Exception e){
        	System.out.println("There Some problem try Again");
		}

		
		
	}
	
	
}
