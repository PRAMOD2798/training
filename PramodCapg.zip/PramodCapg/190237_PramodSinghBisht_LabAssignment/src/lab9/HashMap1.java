package lab9;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class HashMap1 
{
    
	public static void main(String[] args) 
	{
		HashMap<String,Integer> map=new HashMap<>();
		map.put("Pramod",997);
		map.put("Mohit", 998);
		map.put("Rohit", 9946);
		map.put("Rohan",9966);
		map.put("Rohan",99486);
        System.out.println(getValue(map));
		
		
			
	
		
		}

	private static List<Integer> getValue(HashMap<String, Integer> map)
	{
		List<Integer> list=new ArrayList<Integer>();
		Set<Entry<String, Integer>> entry=map.entrySet();
	    Iterator<Entry<String, Integer>> itr = entry.iterator();
	    while(itr.hasNext()){
			Entry<String,Integer> key = itr.next();
			list.add(key.getValue());
	    }
	    Collections.sort(list);
		return list ;
	}

	
	}

