package lab9;

import java.util.HashMap;
import java.util.Scanner;


public class HashMap2
{
	public static void main(String argc[])
	{
		Scanner sc=new Scanner(System.in);
	
	String str="";
	System.out.println("Enter String");
	str=sc.next();
	str=str.toLowerCase();
	char[] ch=new char[str.length()];
	
	for( int i=0;i<ch.length;i++)
	{
		ch[i]=str.charAt(i);
	}
	HashMap<Character,Integer> map=new HashMap<>();
	map=countChar(ch);
	System.out.println(map);
	}

	public static HashMap countChar(char[] character) {
		int[] count=new int[50];
		int len=character.length;
		for(int i=0;i<len;i++)
		{
			count[character[i]-'a']++;
		}
		HashMap<Character,Integer> res=new HashMap<>();
		for(int i=0;i<character.length;i++)
			if(count[character[i]-'a']>0)
			{
				res.put(character[i],count[character[i]-'a']);
			}
		return res;
	}
			
}

	

