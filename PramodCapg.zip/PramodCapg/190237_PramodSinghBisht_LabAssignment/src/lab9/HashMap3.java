package lab9;

import java.util.HashMap;
import java.util.Scanner;

public class HashMap3 {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit");
		int n=sc.nextInt();
		int ar[]=new int[n];
		System.out.println("Enter element");
		for( int i=0;i<n;i++)
		{
			ar[i]=sc.nextInt();
		}
		HashMap<Integer,Integer> map=new HashMap<>();
		map=getSquare(ar);
		System.out.println(map);
	}

	private static HashMap getSquare(int[] ar) 
	{
		HashMap<Integer,Integer> map=new HashMap<>();
		int sq=0;
		for( int i=0;i<ar.length;i++)
		{
			sq=ar[i]*ar[i];
			map.put(ar[i],sq);
		}
		return map;
	}

}
