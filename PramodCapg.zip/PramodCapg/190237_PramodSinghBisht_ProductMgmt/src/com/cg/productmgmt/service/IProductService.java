package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public interface IProductService {
	public Map<String, Integer> updateProducts(String category, int hike) throws ProductException;
	public Boolean validateHike(int hike) throws ProductException;
	public Boolean validateCategory(String prodCat) throws ProductException;
}
