package com.cg.productmgmt.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {

	IProductDAO dao = new ProductDAO();

	@Override
	public Map<String, Integer> updateProducts(String category, int hike) throws ProductException {
		Map<String, Integer> updateMap = dao.updateProducts(category, hike);
		if(updateMap==null)
		{
			throw new ProductException("Empty map.");
		}
		return updateMap;
	}

	@Override
	public Boolean validateHike(int hike) throws ProductException {
		if (hike > 0) {
			return true;
		} else {
			throw new ProductException("Hike price should be greater than 0.");
		}
	}

	@Override
	public Boolean validateCategory(String prodCat) throws ProductException {
		Map<String, String> map = new HashMap<String, String>();
		boolean result = false;
		map = ProductDAO.getMap();
		Iterator<Entry<String, String>> itr = map.entrySet().iterator();
		while (itr.hasNext()) {
			if (prodCat.equals(itr.next().getValue())) {
				result = true;
			}
		}
		if (result == true) {
			return true;
		} else {
			throw new ProductException("Category not found.");
		}
	}
}
