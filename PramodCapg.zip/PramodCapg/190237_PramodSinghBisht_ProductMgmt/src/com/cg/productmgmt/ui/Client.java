package com.cg.productmgmt.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client 
{

	public static void main(String[] args) {
		System.out.println("***********Welcome***********");
		Scanner scan = new Scanner(System.in);
		ProductService service = new ProductService();
		int  hike = 0;
		String cat = "";
		boolean flag = true;
		while (flag) {
			System.out.println("1.Update Product Price\n2.Exit");
			
			System.out.print("Enter your choice:");
			int ch = scan.nextInt();
			switch (ch) {
			case 1:
				System.out.print("Enter the product category:");
				try {
					  cat = scan.next();
					 service.validateCategory(cat);
				} catch (ProductException e) {
					System.out.println(e.getMessage());
					break;
				}
				System.out.print("Enter hike Rate(in %):");
				try {
					hike = scan.nextInt();
					service.validateHike(hike);
				} catch (ProductException e) {
					System.out.println(e.getMessage());
					break;
				}
				Map<String, Integer> map = new HashMap<>();

				try {
					map = service.updateProducts(cat, hike);
				} catch (ProductException e) {
					System.out.println(e.getMessage());
				}
					if (map != null) {
						Iterator<Entry<String, Integer>> itr = map.entrySet().iterator();
						while (itr.hasNext()) {
							System.out.println(itr.next());
						}
					}
				break;
			case 2:
				flag = false;
				break;
			default:
				System.out.println("Wrong choice, please try again!!.");
			}
		}
		scan.close();
	}
}
