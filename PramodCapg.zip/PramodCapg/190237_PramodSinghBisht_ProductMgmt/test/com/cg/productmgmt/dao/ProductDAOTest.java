package com.cg.productmgmt.dao;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmgmt.exception.ProductException;



class ProductDAOTest {
     
	ProductDAO target;
	@BeforeEach
	void setUp() throws Exception 
	{
		target=new ProductDAO();
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		target=new ProductDAO();
	}
	@Test
	void test() throws ProductException 
	{
		Map<String,Integer> hm=new HashMap<String,Integer>();
		hm=target.updateProducts("electronics",100);
		assertNotNull(hm);
	}

}
