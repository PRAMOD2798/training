package com.cg.productmgmt.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

class ProductServiceTest {

	ProductService target;
	@BeforeEach
	void setUp() throws Exception 
	{
		target=new ProductService();
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		target=new ProductService();
	}
	@Test
	void test() throws ProductException 
	{
		boolean result=target.validateHike(10);
		assertTrue(result);
	}
	
	@Test
	
	void testvalidateCategory() throws ProductException
	{
		boolean resul=target.validateCategory("soap");
		assertTrue(resul);
	}

}
