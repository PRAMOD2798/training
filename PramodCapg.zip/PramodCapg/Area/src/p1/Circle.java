package p1;

public class Circle extends Shape
{
public double  area(int radius)
{   
	double areaa=Math.PI*radius*radius;
	return areaa;
}

@Override
public double  area(double length,double breadth ) {
	
	return 0;
}
}
