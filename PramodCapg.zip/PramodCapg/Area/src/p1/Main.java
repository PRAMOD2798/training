package p1;
import java.util.*;
import java.util.Scanner;

public class Main 
{
	 public static void main(String argc[])
	   {
		  Circle c=new Circle();
		  Reactangle r=new Reactangle();
		  Scanner sc=new Scanner(System.in);
		  int choice=0;
		  do
			  {
			  System.out.println("1. Area of Circle:");
			  System.out.println("2. Area of Reactanle:");
			  System.out.println("3.Quit :");
			  System.out.println("Enter your choice :");
			   choice=sc.nextInt();
			  switch(choice)
			  
		      {
		      case 1:
			  System.out.println("Enter Radius:");
			  int radius=sc.nextInt();
			  double areac=c.area(radius);
			  System.out.println("Area of Circle:"+areac);
			  break;
		      case 2:
			  System.out.println("Enter length:");
			  double  length=sc.nextInt();
			  System.out.println("Enter breadth:");
			  double breadth=sc.nextInt();
			  double raar=r.area(length,breadth);
			  System.out.println("Area of Rectangle:"+raar);
			  break;
		      case 3:
		    	  System.out.println("Thankyou");
			  break;
			  default:
				  System.out.println("Invalid choice");
		  }
			  
			  
		  }while(choice<3);
	   }
}
