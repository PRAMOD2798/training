package p1;

public class Reactangle extends Shape
 {
	public double area(double length,double breadth)
	{
		double arerr=length*breadth;
		return arerr;
	}
 public double area(int n)
 {
	return 0;
 }

}
