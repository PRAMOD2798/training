package p1;
import java.util.*;
abstract public class Shape 
{
   abstract public double area(int radius);
   
   abstract public double area(double length,double breadth);
   
  
}
