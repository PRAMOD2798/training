package com.walletapp.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.walletapp.model.WalletAccount;

public class WalletDaoImpl implements WalletDao {

	private static Map<Integer, WalletAccount> accountMap = new HashMap<>();
	// private static Map<Integer, ArrayList<String>> transactionMap = new
	// HashMap<>();
	static int accountNumber = 0;

	@Override
	public boolean createAccount(WalletAccount wa) {
		++accountNumber;
		accountMap.put(accountNumber, wa);
		wa.setAccountNumber(accountNumber);
		return true;
	}

	@Override
	public double readBalance(int accountNumber) {
		Set<Integer> keySet = accountMap.keySet();
		Iterator<Integer> itr = keySet.iterator();
		while (itr.hasNext()) {
			int key = itr.next();
			WalletAccount value = accountMap.get(key);
			if (accountNumber == value.getAccountNumber()) {
				return value.getAccountBalance();
			}
		}
		return 0;
	}

	@Override
	public double updateMoney(int accountNumber, double money) {
		double newBalance = 0.0;
		boolean flag = false;
		Set<Integer> keySet = accountMap.keySet();
		Iterator<Integer> itr = keySet.iterator();
		while (itr.hasNext()) {
			int key = itr.next();
			WalletAccount value = accountMap.get(key);
			if (accountNumber == value.getAccountNumber()) {
				flag = true;
				value.setAccountBalance(value.getAccountBalance() + money);
				newBalance = value.getAccountBalance();
				/*
				 * transactionMap.put(accountNumber, new ArrayList<>());
				 * transactionMap.get(accountNumber).add(money + " is added to your account.");
				 */
				value.setTransaction(money + " is added to your account."+"\n");
			}
		}
		if (flag == true)
			return newBalance;
		else
			return 0;
	}

	@Override
	public double transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		double newBalance = 0.0;
		Set<Integer> keySetFrom = accountMap.keySet();
		Iterator<Integer> itrFrom = keySetFrom.iterator();

		Set<Integer> keySetTo = accountMap.keySet();
		Iterator<Integer> itrTo = keySetTo.iterator();

		WalletAccount valueFrom = new WalletAccount();
		WalletAccount valueTo = new WalletAccount();
		while (itrFrom.hasNext()) {
			int keyFrom = itrFrom.next();
			valueFrom = accountMap.get(keyFrom);
			if (accountNumberFrom == valueFrom.getAccountNumber()) {
				while (itrTo.hasNext()) {
					int keyTo = itrTo.next();
					valueTo = accountMap.get(keyTo);
					if (accountNumberTo == valueTo.getAccountNumber()) {
						if (valueFrom.getAccountBalance() >= 100) {
							newBalance = valueTo.getAccountBalance() + money;
							valueFrom.setAccountBalance(valueFrom.getAccountBalance() - money);
							valueFrom.setAccountBalance(newBalance);
							// transactionMap.put(accountNumberFrom, desc);
							/*
							 * transactionMap.get(accountNumberFrom) .add(money + " is transfered to " +
							 * valueTo.getAccountName()); transactionMap.put(accountNumberTo, new
							 * ArrayList<>()); transactionMap.get(accountNumberTo) .add(money +
							 * " is received from " + valueFrom.getAccountName());
							 */
							valueFrom.setTransaction(money + " is  transfered to " + valueTo.getAccountName()+"\n");
							valueTo.setTransaction("You receive " + money + " from " + valueTo.getAccountName()+"\n");
							return newBalance;
						}
					}
				}
			}
		}
		return 0;
	}

	@Override
	public WalletAccount deleteMoney(int accountNumber, double amountWithdraw) {
		Set<Integer> setKey = accountMap.keySet();
		Iterator<Integer> itr = setKey.iterator();
		while (itr.hasNext()) {
			Integer key = itr.next();
			WalletAccount value = accountMap.get(key);
			if (key == accountNumber) {
				if (value.getAccountBalance() > amountWithdraw) {
					/*
					 * transactionMap.put(accountNumber, new ArrayList<>());
					 * transactionMap.get(accountNumber).add(amountWithdraw +
					 * " is withdrawn from your account.");
					 */
					value.setTransaction(amountWithdraw + " is withdrawn from your account.\n");
					value.setAccountBalance(value.getAccountBalance() - amountWithdraw);
					return value;
				}
			}
		}
		return null;
	}

	@Override
	public String[] readTransaction(int accountNumber) {
		Iterator<Entry<Integer, WalletAccount>> itr = accountMap.entrySet().iterator();
		while (itr.hasNext()) {
			WalletAccount value = itr.next().getValue();
			if (value.getAccountNumber() == accountNumber) {
				return value.getTransaction();
			}
		}
		return null;
	}
}
