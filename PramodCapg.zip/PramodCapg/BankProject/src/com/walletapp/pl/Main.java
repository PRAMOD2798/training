package com.walletapp.pl;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.walletapp.model.WalletAccount;
import com.walletapp.service.WalletService;
import com.walletapp.service.WalletServiceImpl;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		WalletService service = new WalletServiceImpl();
		int choice = 0, accountNumber = 0, accountNumberTo = 0;
		long mobileNumber = 0;
		double money = 0.0, amount = 0.0;
		String accountName = "", email = "";
		boolean flag = true;

		while (flag) {
			System.out.println("******Welcome to Wallet System******");
			System.out.println("1. Create Account");
			System.out.println("2. Check Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Transfer");
			System.out.println("5. Withdraw");
			System.out.println("6. Show Transaction");
			System.out.println("7. Quit");
			System.out.print("Enter your choice:");
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				while (true) {
					System.out.print("Enter your name:");
					accountName = scan.next();
					if (Pattern.matches("^[a-zA-Z]+$", accountName)) {
						break;
					} else {
						System.out.println("Please enter your name correctly.");
					}
				}
				while (true) {
					System.out.print("Enter your email Id:");
					email = scan.next();
					if (Pattern.matches(
							"^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$",
							email)) {
						break;
					} else {
						System.out.println("Please enter valid email.");
					}
				}
				while (true) {
					System.out.print("Enter mobile number:");
					mobileNumber = scan.nextLong();
					if (Pattern.matches("(0/91)?[7-9][0-9]{9}", Long.toString(mobileNumber))) {
						break;
					} else {
						System.out.println("Please enter valid mobile number.");
					}
				}
				WalletAccount wa = new WalletAccount(accountName, email, mobileNumber);
				if (service.addAccount(wa)) {
					System.out.println(
							"Your account has been created and your account number is:" + wa.getAccountNumber() + "\n");
				} else {
					System.out.println("Problem occured while creating account.\n");
				}
				break;
			case 2:
				while (true) {
					System.out.print("Enter your account number:");
					accountNumber = scan.nextInt();
					if (Pattern.matches("[1-9]+", Integer.toString(accountNumber))) {
						break;
					} else {
						System.out.println("Please enter correct account number.");
					}
				}
				double balance = service.showBalance(accountNumber);
				System.out.println("Your total balance is " + balance + "\n");
				break;
			case 3:
				while (true) {
					System.out.print("Enter your account number:");
					accountNumber = scan.nextInt();
					if (Pattern.matches("[1-9]+", Integer.toString(accountNumber))) {
						break;
					} else {
						System.out.println("Please enter correct account number.");
					}
				}
				while (true) {
					System.out.print("Enter amount to deposit:");
					money = scan.nextDouble();
					if (Pattern.matches("\\d+\\.?\\d+", Double.toString(money)) && money >= 100.0) {
						break;
					} else {
						System.out.println("Please enter amount greater than or equal to 100.");
					}
				}
				double newBalance = service.depositMoney(accountNumber, money);
				if (newBalance > 0)
					System.out.println("Your new balance is " + newBalance + "\n");
				else
					System.out.println("Problem while deposting money.\n");
				break;
			case 4:
				while (true) {
					System.out.print("Enter money sender account number:");
					accountNumber = scan.nextInt();
					System.out.print("Enter money receiver account number:");
					accountNumberTo = scan.nextInt();
					if (Pattern.matches("[1-9]+", Integer.toString(accountNumber))
							&& Pattern.matches("[1-9]+", Integer.toString(accountNumberTo))) {
						break;
					} else {
						System.out.println("Please enter correct account number.");
					}
				}
				while (true) {
					System.out.print("Enter amount to transfer:");
					money = scan.nextDouble();
					if (Pattern.matches("\\d+\\.?\\d+", Double.toString(money)) && money >= 100.0) {
						break;
					} else {
						System.out.println("Please enter amount greater than or equal to 100.");
					}
				}
				amount = service.transferMoney(accountNumber, accountNumberTo, money);
				if (amount > 0) {
					System.out.println(
							"Amount:" + money + " is transfered to account id:" + accountNumberTo + " successfully.\n");
				} else {
					System.out.println("Problem while transfering money.\n");
				}
				break;
			case 5:
				while (true) {
					System.out.print("Enter your account number:");
					accountNumber = scan.nextInt();
					if (Pattern.matches("[1-9]+", Integer.toString(accountNumber))) {
						break;
					} else {
						System.out.println("Please enter correct account number.");
					}
				}
				while (true) {
					System.out.print("Enter amount to withdraw:");
					amount = scan.nextDouble();
					if (Pattern.matches("\\d+\\.?\\d+", Double.toString(amount)) && amount >= 100.0) {
						break;
					} else {
						System.out.println("Please enter amount greater than or equal to 100.");
					}
				}
				WalletAccount updatedBalance = service.withDrawMoney(accountNumber, amount);
				if (updatedBalance != null) {
					System.out.println("Money has been withdrawn successfully.");
					System.out.println("Your new balance:" + updatedBalance.getAccountBalance());
				} else {
					System.out.println("Money cannot be withdrawn.");
				}
				break;
			case 6:
				while (true) {
					System.out.print("Enter account number:");
					accountNumber = scan.nextInt();
					if (Pattern.matches("[1-9]+", Integer.toString(accountNumber))) {
						break;
					} else {
						System.out.println("Please enter correct account number.");
					}
				}
				String[] transaction = service.showTransaction(accountNumber);
				if (transaction != null) {
					System.out.println("*************Transaction Details************");
					for (int i = 0; i < transaction.length; i++) {
						if (transaction[i] != null) {
							System.out.println(transaction[i]);
						}
					}
				} else {
					System.out.println("Problem occured while reading transaction.");
				}
				break;
			case 7:
				flag = false;
				break;
			default:
				System.out.println("Wrong choice, Please try again.");
			}
		}
		scan.close();
	}
}
