package Dao;

public interface BookDao {

}
