package Dao;

public class BookDaoImpl 
{

}
