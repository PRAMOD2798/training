package Model;

public class Book 
{
private String bookname;
private int price;
public String getBookname()
{
	return bookname;
}
public Book(String bookname, int price) {
	super();
	this.bookname = bookname;
	this.price = price;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() {
	return "Book [bookname=" + bookname + ", price=" + price + "]";
}
}
