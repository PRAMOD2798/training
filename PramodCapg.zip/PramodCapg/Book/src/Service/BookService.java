package Service;

public interface BookService
{
  public void showKey();
  public void showvalue();
  public void showKeyValue();
}
