package Service;

public class BookServiceImpl implements BookService
{

	@Override
	public void showKey() {
		
		
	}

	@Override
	public void showvalue() {
		
	}

	@Override
	public void showKeyValue() {
		
		
	}

}
