package lab2;

class Book extends WrittenItem

{
	
	
	

	

    public Book(int bookid, String title, int number, String author) {
		super(bookid, title, number, author);
	
	}

	public void print() {
	
	super.print();
     }

	public void checkIn() {
	
		super.checkIn();
	}
	
	public void checkOut() {

		super.checkOut();
	}

	
	public void addItem() {
		
		
	}
	

	
	
}