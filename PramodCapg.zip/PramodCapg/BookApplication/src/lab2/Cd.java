package lab2;

public class Cd extends MediaItem
{

private String musicg;
private String artistname;

	
	
public Cd(int bookid, String title, int number, int runtime, String musicg, String artistname) {
	super(bookid, title, number, runtime);
	this.musicg = musicg;
	this.artistname = artistname;
}






	public void print() {
		
		super.print();
		System.out.println("Music G:"+musicg);
		System.out.println("Artist Name:"+artistname);
	}

	public String getMusicg() {
		return musicg;
	}




	public void setMusicg(String musicg) {
		this.musicg = musicg;
	}




	public String getArtistname() {
		return artistname;
	}




	public void setArtistname(String artistname) {
		this.artistname = artistname;
	}




	public void checkOut() {
	
	}

	public void checkIn()
	{
		
		
	}

	public void addItem() {
		
		
	}


}
