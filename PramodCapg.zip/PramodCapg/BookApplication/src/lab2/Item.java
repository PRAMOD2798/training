package lab2;

public abstract class Item 
{
    private int bookId;
    private String title;
    private int number;
    
    public Item(int bookId,String title,int number)
    {
    	this.bookId=bookId;
    	this.title=title;
    	this.number=number;
    }
    
    public abstract void addItem();
    
    public abstract void checkIn();
    public abstract void checkOut();
    public void print()
	  {
		System.out.println("BookId:"+bookId);
		System.out.println("BookTitle:"+title);
		System.out.println("NumberofCopies:"+number);
	  }
    
    public int setbookId(int bookId)
     {
    	 this.bookId=bookId;
    	 return getBookId();
     }
     public String settitle(String title)
     {
    	 this.title=title;
    	 return title;
     }
     public int setnumber(int number)
     {
    	 this.number=number;
    	 return  number;
     }
     public int getbookId()
     {
    	 
    	 return getBookId();
     }
     public String gettitle()
     {
    	
    	 return title;
     }
     public int getnumber()
     {
    	
    	 return  number;
     }
      
     
     
	 
        public int getBookId() {
		return bookId;
	 }
	    public void setBookId(int bookId) {
		this.bookId = bookId;
	     }

	public String toString() {
		return "Item [bookId=" + bookId + ", title=" + title + ", number=" + number + "]";
	}
    
   
   
   
   
}
