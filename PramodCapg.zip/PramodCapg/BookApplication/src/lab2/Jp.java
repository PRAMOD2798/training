package lab2;

public class Jp extends WrittenItem
{
	private int yp;
	
        public Jp(int bookid, String title, int number, String author,int yp) {
		super(bookid, title, number, author);
		this.yp=yp;
	}


	
		public void print() {
			
			super.print();
			System.out.println("Year of Application:"+yp);
		}
	
	public int getYp() {
			return yp;
		}



		public void setYp(int yp) {
			this.yp = yp;
		}



	public void checkIn() {
		
		
	}

	public void checkOut()
	{
		
		
	}

	
	public void addItem() {
		
		
	}

}
