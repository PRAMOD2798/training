package lab2;

public class MainClass 
{
  public static void main(String argc[])
  {
	  Book[] b=new Book[4];
	  Jp[] j=new Jp[10];
	  Vedio v[]=new Vedio[8];
	  Cd c[]=new Cd[10];
	  
	  Book b1=new Book(1,"java",3,"Unknown");
	  Book b2=new Book(2,"C++",5,"Unknown");
	  Book b3=new Book(3,"DAA",6,"Unknown");
	  Book b4=new Book(4,"Python",7,"Unknown");
	  
	  b[0]=b1;
	  b[1]=b2;
	  b[2]=b3;
	  b[3]=b4;
	  for(int i=0;i<4;i++)
	  {
		  b[i].print();
	  }
  }
}
