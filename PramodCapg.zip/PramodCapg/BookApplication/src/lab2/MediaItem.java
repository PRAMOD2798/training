package lab2;

public  abstract class MediaItem extends Item
{
private int  runtime;
	public MediaItem(int bookid, String title, int number,int runtime) {
		super(bookid, title, number);
		this.runtime=runtime;
		
	}
	
	
		public int getRuntime() {
		return runtime;
	}


	
		public void print() {
			
			super.print();
			System.out.println("Runtime:"+runtime);
		}
			public void setRuntime(int runtime)
			{
			this.runtime = runtime;
		    }


			public String toString() {
			
				return super.toString()+runtime;
			}
			public void checkIn() 
			{
	
				
			}
			
				public void checkOut() {
				
					
				}
				

}

