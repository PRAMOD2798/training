package lab2;

class Vedio extends MediaItem
{

    private String director;
	
	public Vedio(int bookid, String title, int number, int runtime,String director) {
		super(bookid, title, number, runtime);
		this.director=director;
	}
	@Override
	public void print() {
	
        super.print();
		System.out.println("Director"+director);
	}

	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public void addItem() {
		
		
	}
	
	public void checkIn() {
		
	}
	 
	public void checkOut() {
		
	}

	
	
}