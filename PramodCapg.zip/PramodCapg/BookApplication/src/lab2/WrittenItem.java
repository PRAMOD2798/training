package lab2;

public  abstract class WrittenItem extends Item
{
    private String author;
	public WrittenItem (int bookid, String title, int number,String author) {
		super(bookid, title, number);
		this.author=author;
		
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthor() 
	{
		return author;
	}
	
	
			public void print() {
				
				super.print();
				System.out.println("Author:"+author);
			}
		
			public String toString() {
			
				return super.toString()+author;
			}
			public void checkIn() 
			{
	
				
			}
			
				public void checkOut() {
				
					
				}
				

}


