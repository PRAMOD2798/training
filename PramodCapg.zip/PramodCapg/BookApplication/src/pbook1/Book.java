package pbook1;

public class Book 
	{
	 public Book()
     {
    	 this("","","",-1);
		 System.out.println("Default"); 
     }
     public Book(String isbn,String author,String title,double price )
     {
    	 System.out.println("Parameter constructor");
    	 this.isbn=isbn;
    	 this.author=author;
    	 this.title=title;
    	 this.price=price;
    	 
     }
     protected void finalize()
     {
    	 System.out.println("object deleted");
    	 
     }
     private String author,isbn,title;
     private double price;
	public String getAuthor() {
		return author;
	}
	public String getIsbn() {
		return isbn;
	}
	public String getTitle() {
		return title;
	}
	public double getPrice() {
		return price;
	}
    
	}
