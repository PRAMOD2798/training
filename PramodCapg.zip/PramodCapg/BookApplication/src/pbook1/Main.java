package pbook1;

public class Main 
{
	public static void main(String args[])
	{
		Book b1=new Book();
		Book b2=new Book("1000","Java 8 Book","Unknown",150.50);
		b1=b2;
		System.out.println("End of main");
		System.gc();
	}
}
