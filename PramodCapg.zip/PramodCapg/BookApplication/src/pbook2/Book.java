package pbook2;

public class Book 
	{
	 private String author,isbn,title;
     private double price;
     private static double discount;
     static{
    	 Book.discount=5;
     }
     public static void setDiscount(double discount)
     {
    	 Book.discount=discount;
     }
     private double caldiscount()
     {
    	 return price-(price*discount)/100.0;
     }
     public void display()
     {
    	 System.out.println("Isbn: "+isbn);
    	 System.out.println("Title: "+title);
     
    	 System.out.println("author: "+author);
    	 System.out.println("price: "+price);
    	 System.out.println("price after discount"+caldiscount());
     }
	 public Book()
     {
    	 this("","un","un",-1);
		 System.out.println("Default"); 
     }
     public Book(String isbn,String author,String title,double price )
     {
    	 System.out.println("Parameter constructor");
    	 this.isbn=isbn;
    	 this.author=author;
    	 this.title=title;
    	 this.price=price;
    	 
     }
     protected void finalize()
     {
    	 System.out.println("object deleted");
    	 
     }
    
	public String getAuthor() {
		return author;
	}
	public String getIsbn() {
		return isbn;
	}
	public String getTitle() {
		return title;
	}
	public double getPrice() {
		return price;
	}
    
	}
