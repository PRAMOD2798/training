package pbook2;

public class Main 
{
	public static void main(String args[])
	{
		Book b1=new Book("1000","Java 7 Book","Unknown",130.50);
		Book b2=new Book("1000","Java 8 Book","Unknown",150.50);
		b1.display();
		b2.display();
		Book.setDiscount(10);
		b1.display();
		b2.display();
		System.out.println("End of main");
		
	}
}
