package capgemini;

public class Employee
{
		private int employeeId;
		private String emloyeename;

		private double employeeSalary;
       
		
		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", emloyeename=\n" + emloyeename + ", employeeSalary="
					+ employeeSalary + "]";
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + employeeId;
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Employee other = (Employee) obj;
			if (employeeId != other.employeeId)
				return false;
			return true;
		}

		public Employee(int employeeId, String emloyeename, double employeeSalary) {
			super();
			this.employeeId = employeeId;
			this.emloyeename = emloyeename;
			this.employeeSalary = employeeSalary;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getEmloyeename() {
			return emloyeename;
		}

		public void setEmloyeename(String emloyeename) {
			this.emloyeename = emloyeename;
		}

		public double getEmployeeSalary() {
			return employeeSalary;
		}

		public void setEmployeeSalary(double employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
}
