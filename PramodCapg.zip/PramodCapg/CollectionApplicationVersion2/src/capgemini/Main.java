package capgemini;

import java.util.HashSet;

public class Main {

	public static void main(String[] args) 
	{
	 HashSet<Employee> employeeDb=new HashSet<Employee>();
	 Employee e1=new Employee(12,"Pramod",4500);
	 Employee e2=new Employee(14,"Rahul",4300);
	
	 employeeDb.add(e1);
	 employeeDb.add(e2);
	 Employee e3=new Employee(14,"Rahul",4300);
	 employeeDb.add(e3);
	 
	// Employee e4=e1;
	 //employeeDb.add(e4);
	 System.out.println(e1.hashCode()+","+e2.hashCode()+","+e3.hashCode());
	System.out.println(employeeDb);
	}

}
