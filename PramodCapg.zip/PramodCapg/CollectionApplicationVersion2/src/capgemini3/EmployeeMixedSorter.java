package capgemini3;

import java.util.Comparator;

public class EmployeeMixedSorter implements Comparator<Employee>
{

	
	public int compare(Employee o1, Employee o2) 
	{

		if( o1.getEmployeeSalary()>o2.getEmployeeSalary())
		{
			return -1;
	    }
		else if( o1.getEmployeeSalary()>o2.getEmployeeSalary())
			return o1.getEmloyeename().compareTo(o2.getEmloyeename());
		else 
			return 1;
	}

}
