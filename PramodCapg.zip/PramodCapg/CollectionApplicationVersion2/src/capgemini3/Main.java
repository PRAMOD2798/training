package capgemini3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;





public class Main {

	public static void main(String[] args) 
	{
	 List<Employee> employeeDb=new ArrayList<Employee>();
	 Employee e1=new Employee(101,"Pramod",4500);
	 Employee e2=new Employee(102,"Rahul",25000);
	 
	 employeeDb.add(e1);
	 employeeDb.add(e2);
	 Employee e3=new Employee(103,"piyush",30000);
	 employeeDb.add(e3);
	// Collections.sort(employeeDb);
//Collections.sort(employeeDb,new EmployeeSalarySorter());

///	System.out.println(employeeDb);
	 Comparator<Employee> comparator=(Employee o1,Employee o2)->{
		 return (o1.getEmployeeSalary()>o2.getEmployeeSalary()?1:-1);
	 };
	Collections.sort(employeeDb,new EmployeeMixedSorter());

	System.out.println(employeeDb);
	
	}

}