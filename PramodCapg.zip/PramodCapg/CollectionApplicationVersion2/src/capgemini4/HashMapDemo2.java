package capgemini4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapDemo2
{
	public static void main(String[] args) 
	{
		HashMap<String,Long> map=new HashMap<>();
		map.put("Pramod", 9987734567L);
		map.put("Mohit",  9987734556L);
		map.put("Rohit",  9946665675L);
		map.put("Rohan", 9946665695L);
		map.put("Rohan", 9948665695L);
		System.out.println(map.toString());
		System.out.println(map.size());
		System.out.println(map.entrySet());
		System.out.println(map.keySet());
		
	
		Set<String> keys=map.keySet();
		 Iterator<String> itr= keys.iterator();
		while(itr.hasNext()){
			String key = itr.next();
			Long value =map.get(key);
			System.out.println(key+"-"+value);
		}
	
	}
}
