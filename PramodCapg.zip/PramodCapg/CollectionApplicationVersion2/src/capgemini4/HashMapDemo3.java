package capgemini4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo3 {
	public static void main(String[] args) 
	{
		HashMap<String,Long> map=new HashMap<>();
		map.put("Pramod", 9987734567L);
		map.put("Mohit",  9987734556L);
		map.put("Rohit",  9946665675L);
		map.put("Rohan", 9946665695L);
		map.put("Rohan", 9948665695L);
	
		Set<Entry<String, Long>> entry=map.entrySet();
	    Iterator<Entry<String,Long>> itr = entry.iterator();
		
		while(itr.hasNext()){
			Entry<String,Long> e = itr.next();
		
			System.out.println(e.getKey()+"-"+e.getValue());
		}
	
	}
}
