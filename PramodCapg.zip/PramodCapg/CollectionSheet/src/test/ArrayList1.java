package test;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList1 
{
	public static void main(String argc[])
	{
	ArrayList<String> list=new ArrayList<String>();
    String str="Capgemini Mumbai";
	list.add(str);
	String str2="pune";
	list.add(str2);
	String str3="Noida";
	list.add(str3);
	
    printAll(list);

	}
	private static void printAll(ArrayList<String> list) 
	{
		Iterator<String> itr=list.iterator();
		while(itr.hasNext()){
			Object obj=itr.next();
			System.out.println(obj);
	}
}
	}
