package test;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList2 
{
public static void main(String argc[])
	{
	ArrayList<Number> list=new ArrayList<Number>();
	
	list.add(10.56);
	
	list.add(500);
	
	list.add(15.7789);
	
	printAll(list);

	}
	private static void printAll(ArrayList<Number> list) 
	{
		Iterator<Number> itr=list.iterator();
		while(itr.hasNext()){
		Object obj=itr.next();
		System.out.println(obj);
	}
}

}
