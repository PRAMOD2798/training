package test;


import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TreeSet1
{
	public static void main(String argc[])
	{
		TreeSet<String> ts=new TreeSet<String>();
		
		ts.add("Pramod");
		ts.add("Anu");
		ts.add("Mohit");
		ts.add("Rohit");
		ts.add("Rahul");
		System.out.println(""+ts);
		System.out.println("After reverse:");
		 ts = (TreeSet)ts.descendingSet();
		
	
	
		Iterator<String> itr=ts.iterator();
		while(itr.hasNext()){
		Object obj=itr.next();
		System.out.println(obj);
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Check exist or not");
		 String str=sc.next();
		boolean isExists = ts.contains(str);
		 System.out.println("exists in treeSet " + isExists); 
		
		
	
	}
}
