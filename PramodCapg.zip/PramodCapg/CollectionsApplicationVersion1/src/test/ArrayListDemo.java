package test;

import java.util.ArrayList;

public class ArrayListDemo 
{
	public static void main(String argc[])
	{
	ArrayList<Object> list=new ArrayList<Object>();

	boolean result=list.add("Capgemini pune");
	list.add(new Integer(10000));
	list.add(new Double(100.5));

	String str="Capgemini Mumbai";
	list.add(str);
	int size=list.size();
	System.out.println("Size if list"+size);
	
	int number=1000;
	list.add(number);
	
	list.add(2,"pune");
	System.out.println(list.toString());

	}
}
