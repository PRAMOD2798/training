package test;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ArrayListDemo2 
{
	public static void main(String argc[])
	{
	ArrayList<Integer> list=new ArrayList<Integer>();

	
	list.add(1000);
	list.add(200);
	list.add(1500);
	list.add(1400);
	
	System.out.println("Before Sorting");
	System.out.println(list.toString());
	
	Collections.sort(list);
	System.out.println("Before Sorting");
	System.out.println(list);
	}
}

