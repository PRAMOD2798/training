package test;

import java.util.HashSet;
import java.util.Iterator;



public class HashSetDemo2 
{
	public static void main(String argc[])
	{
	HashSet<Object> hs=new HashSet<Object>();

	boolean result=hs.add("Capgemini pune");
	hs.add(new Integer(10000));
	hs.add(new Double(100.5));

	String str="Capgemini Mumbai";
	hs.add(str);


	int number=1000;
	hs.add(number);
	
	Iterator<Object> itr=hs.iterator();
	while(itr.hasNext()){
		Object obj=itr.next();
		System.out.println(obj);
	}

	}
}
