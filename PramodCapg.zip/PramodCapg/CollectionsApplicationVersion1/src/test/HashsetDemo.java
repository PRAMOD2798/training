package test;


import java.util.HashSet;
public class HashsetDemo 
{
	public static void main(String argc[])
		{
		HashSet<Object> hs=new HashSet<Object>();
	
		boolean result=hs.add("Capgemini pune");
		hs.add(new Integer(10000));
		hs.add(new Double(100.5));
	
		String str="Capgemini Mumbai";
		hs.add(str);
	
		System.out.println(hs.toString());
		int number=1000;
		hs.add(number);
		
		System.out.println(hs.toString());
	
		}
}