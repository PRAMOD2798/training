package test;

import java.util.TreeSet;

public class TreeSetDemo 
{
	public static void main(String argc[])
	{
		TreeSet<Integer> ts=new TreeSet<Integer>();
		boolean result=ts.add(50);
		ts.add(10000);
		ts.add(100);

		
		ts.add(50);
	
		
		int number = 1000;
		ts.add(number);
		
		
		System.out.println(ts);
	}
}
