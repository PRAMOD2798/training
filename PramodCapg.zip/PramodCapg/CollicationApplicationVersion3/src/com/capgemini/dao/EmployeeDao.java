package com.capgemini.dao;

import com.capgemini.model.Employee;

public interface EmployeeDao
{
  public boolean createEmployee(Employee employee);
  public Employee readEmployee(int employeeId);
 }
