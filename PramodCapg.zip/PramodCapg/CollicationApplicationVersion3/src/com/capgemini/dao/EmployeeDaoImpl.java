package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao 
{
	private static List<Employee> list=new ArrayList<Employee>();
	
	public boolean createEmployee(Employee employee) {
	    boolean result=list.add(employee);
		return result;
	}


	public Employee readEmployee(int employeeId) {
		Iterator<Employee> itr=list.iterator();
		while(itr.hasNext())
		{
			Employee emp=itr.next();
			if(emp.getEmployeeId()==employeeId)
			{
				return emp;
			}
		}
		return null;
	}

}
