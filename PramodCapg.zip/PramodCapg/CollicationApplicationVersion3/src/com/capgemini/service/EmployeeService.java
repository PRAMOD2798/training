package com.capgemini.service;
import com.capgemini.model.Employee;
public interface EmployeeService 
{
   public boolean addEmployee(Employee employee);
   public Employee getEmployee(int employeeId);
   
}
