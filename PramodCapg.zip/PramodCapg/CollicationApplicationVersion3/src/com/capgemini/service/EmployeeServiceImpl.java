package com.capgemini.service;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.model.Employee;

public class EmployeeServiceImpl implements EmployeeService
{

	private EmployeeDao dao= new EmployeeDaoImpl();
	public boolean addEmployee(Employee employee) 
	{
		boolean result=dao.createEmployee(employee);	
		return result;
	}


	public Employee getEmployee(int employeeId) {
		Employee employee=dao.readEmployee(employeeId);
		return employee;
	}

}
