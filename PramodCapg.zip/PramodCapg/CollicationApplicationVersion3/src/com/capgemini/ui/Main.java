package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.model.Employee;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.EmployeeServiceImpl;

public class Main 
{
public static void main(String argc[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("**********Welcome to EMS**********");
	
	
	 boolean flag=true;
	 while(flag)
		 {
		    System.out.println("1.Add Employee \n2.Get Employee\n3.Delete Employee");
			System.out.println("Enter your Choice:");
			int ch=sc.nextInt();
			 EmployeeService service=new EmployeeServiceImpl();
		 	switch(ch)
		 
		 	{
		 	case 1:
		 		System.out.println("Enter EmployeeId:");
		 		int id=sc.nextInt();
		 		System.out.println("Enter Employee Name:");
		 		String name=sc.next();
		 		System.out.println("Enter Employee Salary:");
		 		double sal=sc.nextDouble();
		 		Employee emp=new Employee(id,name,sal); 
		
		 		boolean result=service.addEmployee(emp);
		 		if(result)
		 		{
		 			System.out.println(" Employee added with"+emp.getEmployeeId());
		 		}
		 		else{
		 			System.out.println(" Problem Occure while adding Employee");
		 		}
		 		break;
	 case 2:
		 System.out.println("Enter EmployeeId:");
		  id=sc.nextInt();
		  Employee employee=service.getEmployee(id);
		  System.out.println(employee.toString());
		  break;
	 case 3:
		 System.out.println("Enter EmployeeId:");
		  id=sc.nextInt();
		  Employee employe=service.getEmployee(id);
		  System.out.println(employe.remove(id));
		  default:
			  System.out.println("Wrong choice! please try again");
		 
	 }
		 
	
	}
}
}
