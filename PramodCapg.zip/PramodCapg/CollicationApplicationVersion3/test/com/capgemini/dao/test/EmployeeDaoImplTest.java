package com.capgemini.dao.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.model.Employee;

class EmployeeDaoImplTest {
	private EmployeeDaoImpl dao;
	@BeforeEach
	void setUp() throws Exception {
		 dao = new EmployeeDaoImpl();
	}

	@AfterEach
	void tearDown() throws Exception {
		dao=null;
	}

	@Test
	void testCreateEmployeeShouldAddEmployeeToListAndReturnTrue()
	{
		Employee employee=new Employee(100,"Pramod",5000);
	    boolean result=dao.createEmployee(employee);
	    assertTrue(result);
	   /* result=dao.createEmployee(employee);
	    assertFalse(result);
	*/}

	@Test
	void testReadEmployee() 
	{
	
	 Employee employee=new Employee(100,"Pramod",5000);
	 dao.createEmployee(employee);
	 Employee emp1=dao.readEmployee(100);
	 assertNotNull(emp1);
	
	
	 
	}

}
