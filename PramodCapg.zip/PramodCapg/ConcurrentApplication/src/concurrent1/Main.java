package concurrent1;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Main implements Runnable {
	 
	static List<String> list=new CopyOnWriteArrayList<>();
	public static void main(String[] args)
	{
			list.add("Mumbai");
			list.add("Pune");
			list.add("Delhi");
			
			
			Thread t1=new Thread();
			t1.start();
	

	
		Iterator<String> itr= list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
			
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				
			}
			
		
	      }
		
	

}
	public void run() {
		list.add("kanpur");
		try{
			Thread.sleep(100);
		}
		catch(InterruptedException e){}
		list.add("Patana");
	}
	}
