package test;

import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestDatabase1 {

	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	  
		try{
	    	 
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");
	     
		
		   System.out.println("1.Add Employee");
		    System.out.println("2.Find All Employee");
		    System.out.println("3.Find Employee");
		    System.out.println("4.Delete Employee");
		    System.out.println("5.Enter your Choice");
		    int ch=sc.nextInt();
		    Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl","seed28","seed28");
			 Statement  s= conn.createStatement();
			 String query="select * from emp1";
			 ResultSet rs=s.executeQuery(query);
			switch(ch)
			{
			case 1:
				System.out.println("Enter the employee id:");
				int emp_idd=sc.nextInt();
				System.out.println("Enter the Name:");
				String empp_name=sc.next();
				System.out.println("Enter the Salary:");
				double emp_sall=sc.nextDouble();
				System.out.println("Enter the department id:");
				int emp_dpid=sc.nextInt();
				System.out.println("Enter the mgr id:");
				int mgr_id=sc.nextInt();
				System.out.println("Enter the email ");
				String email_id=sc.next();
				String sql = "INSERT INTO emp1 VALUES ("+emp_idd+",'"+empp_name+"',"+emp_sall+","+emp_dpid+","+mgr_id+",'"+email_id+"')";
		        s.executeUpdate(sql);
			case 2:
				 while(rs.next())
				   {
					 int emp_id=rs.getInt("Emp_id");
					 String emp_name=rs.getString("Emp_Name");
					 double emp_sal=rs.getDouble("Emp_Salary");
					 
					 System.out.println(emp_id+","+emp_name+","+emp_sal);
				   }
				
			}
		   
		 
	
	    }
			
	     catch(ClassNotFoundException | SQLException e){
	    	 System.out.println("There is name some technical problem");
	    	 System.out.println(e.getMessage());
	     }

}
}
