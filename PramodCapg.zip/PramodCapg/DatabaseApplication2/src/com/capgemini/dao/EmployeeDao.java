package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Employee;

public interface EmployeeDao {
	public int createEmployee(Employee emp);

	public Employee readEmployee(int employeeId);

	public List<Employee> readAllEmployee();

	public int deleteEmployee(int employeeId);

	public Employee updateEmployee(Employee employee);

}
