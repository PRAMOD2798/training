package com.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.exception.TechnicalException;
import com.capgemini.model.Employee;
import com.capgemini.utils.DatabaseUtils;

public class EmployeeDaoImpl implements EmployeeDao
{
     private DatabaseUtils dbUtil=null;
     public EmployeeDaoImpl()
     {
    	 dbUtil=DatabaseUtils.getInstance();
     }
  

	public int createEmployee(Employee emp) {
		try{
	    	 Connection connection=dbUtil.openDatabaseConnection();
	    	 String query="Insert Into emp2(emp_id,emp_name,emp_salary) values(?,?,?)";
	    	 PreparedStatement pstmt=connection.prepareStatement(query);
	    	 pstmt.setInt(1,emp.getEmployeeId());
	    	 pstmt.setString(2, emp.getEmployeeName());
	    	 pstmt.setDouble(3, emp.getEmployeesalary());
	    	int result=pstmt.executeUpdate();
	    	if(result>=0)
	    	{
	    		return result;
	    	}
	    	 
	    	// dbUtil.closeDatabaseConnection();
	    	 }
	    	 catch(SQLException | ClassNotFoundException e){
	        TechnicalException te= new TechnicalException(e,"Thre is some technical issue with opening/closing");
	        throw te;
	    	 }
	    	 
		return 0;
	}

	@Override
	public Employee readEmployee(int employeeId)
	{
		try{
			
		 
		   Connection connection=dbUtil.openDatabaseConnection();
		   String query="select * from emp2 where emp_id='"+employeeId+"'";
		   PreparedStatement psmt=connection.prepareStatement(query);
	       ResultSet rs=psmt.executeQuery(query);
	       while(rs.next())
		   { 
			
	    	   int emp_id=rs.getInt("emp_id");
		         String emp_name=rs.getString("emp_name");
		         Double emp_salary=rs.getDouble("emp_salary");
		         Employee emp=new Employee(emp_id, emp_name, emp_salary);
		   
		     if(emp.getEmployeeId()==emp_id)
		     {
		    		 return emp;
		     }
   	          }
	       }
   	 catch(SQLException |ClassNotFoundException e)
		{
	        TechnicalException te= new TechnicalException(e,"Thre is some technical issue with opening/closing");
	        throw te;
	    	 }
		return null;
	
	}

	@Override
	public List<Employee> readAllEmployee() {
		List<Employee> list=new ArrayList<>();
		try{ 
			Connection connection=dbUtil.openDatabaseConnection();
			 String query="select * from emp2";
			PreparedStatement psmt=connection.prepareStatement(query);
		
			 ResultSet rs=psmt.executeQuery(query);
			 
			 while(rs.next())
			   { 
				
			     int emp_id=rs.getInt("emp_id");
		         String emp_name=rs.getString("emp_name");
		         Double emp_salary=rs.getDouble("emp_salary");
		         Employee emp=new Employee(emp_id, emp_name, emp_salary);
				 list.add(emp);	
			   }
			 return list;
	
   	   
		}
		 catch(SQLException |ClassNotFoundException e){
		        TechnicalException te= new TechnicalException(e,"Thre is some technical issue with opening/closing");
		        throw te;
		    	 }
		
	}

	@Override
	public int deleteEmployee(int employeeId) {
		try{
			
			 
			   Connection connection=dbUtil.openDatabaseConnection();
			   String query="Delete from emp2 where emp_id='"+employeeId+"'";
			   PreparedStatement psmt=connection.prepareStatement(query);
		       ResultSet rs=psmt.executeQuery(query);
		       System.out.println("Record deleted");
		   }
	   	 catch(SQLException |ClassNotFoundException e)
			{
		        TechnicalException te= new TechnicalException(e,"Thre is some technical issue with opening/closing");
		        throw te;
		    	 }
			
		
		
		return 0;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

}


