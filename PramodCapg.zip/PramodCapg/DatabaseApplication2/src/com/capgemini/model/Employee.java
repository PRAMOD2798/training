package com.capgemini.model;

public class Employee 
{
	private int employeeId;
	private String employeeName;
    private double employeesalary;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(double employeesalary) {
		this.employeesalary = employeesalary;
	}
	public Employee(int employeeId, String employeeName, double employeesalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeesalary = employeesalary;
	}
	@Override
	public String toString() 
	{
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeesalary="
				+ employeesalary + "]";
	}


}
