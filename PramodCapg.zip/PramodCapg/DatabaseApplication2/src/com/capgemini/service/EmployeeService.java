package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Employee;

public interface EmployeeService {
	public boolean addEmployee(Employee emp);

	public List<Employee> ShowAllEmployee();

	public Employee FindEmployee(int employeeId);

	public boolean removeEmployee(int employeeId);

	public boolean modifyEmployee(Employee employee);

}
