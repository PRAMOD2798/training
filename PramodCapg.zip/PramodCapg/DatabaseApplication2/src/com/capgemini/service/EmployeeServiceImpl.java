package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.model.Employee;

public class EmployeeServiceImpl implements EmployeeService
{
	private EmployeeDao dao=new EmployeeDaoImpl();
	@Override
	public boolean addEmployee(Employee emp)
	{
       int result=dao.createEmployee(emp);
       if(result>=1)
		return true;
       else
    	   return false;
	}

	@Override
	public List<Employee> ShowAllEmployee() {
		List<Employee> emp=new ArrayList<Employee>();
		emp=dao.readAllEmployee();
		return emp;
	}

	@Override
	public Employee FindEmployee(int employeeId) {
		Employee employee=dao.readEmployee(employeeId);
		return employee;
	}

	@Override
	public boolean removeEmployee(int employeeId) {
		 int resul=dao.deleteEmployee(employeeId);
	       if(resul>=1)
			return true;
	       else
	    	   return false;
		
	}

	@Override
	public boolean modifyEmployee(Employee employee) {

		return false;
	}

}
