package com.capgemini.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.exception.TechnicalException;
import com.capgemini.model.Employee;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.EmployeeServiceImpl;

public class Main {
	public static void main(String argc[]) 
	{   
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Add Employee\n2.Find All Employee\n3.Find Employee\n4.Delete Employee\n5.Update Employee");
		EmployeeService service = new EmployeeServiceImpl();
		System.out.println("Enter your choice:");
		int ch=sc.nextInt();
	
		 switch(ch)
		 {
		 case 1:
		
		    
		       System.out.println("Enter Employee Id:");
			   int emp_id =sc.nextInt();
			   System.out.println("Enter Employee Name:");
			   String emp_name =sc.next();
			   System.out.println("Enter Employee Salary:");
			   double emp_sal =sc.nextDouble();

			   Employee emp = new Employee(emp_id, emp_name, emp_sal);
			   boolean result = service.addEmployee(emp);
			  if (result) {
				System.out.println("employee Added");
			  } else {
				System.out.println("Employee not added");
			  }
		   
		 
		    break;
		 case 2:
			 List<Employee> e=new ArrayList<>();
			 e=service.ShowAllEmployee();
			 Iterator<Employee> itr=e.iterator();
			 while(itr.hasNext())
			 {
			   // Employee en=itr.next();
			    System.out.println(""+itr.next());
			 }
			 
		 case 3:
			  System.out.println("Enter EmployeeId:");
			  int id=sc.nextInt();
			  Employee employee=service.FindEmployee(id);
			  System.out.println(employee.toString());
			  break;
		 case 4:
			  System.out.println("Enter EmployeeId:");
			  int idd=sc.nextInt();
			  service.removeEmployee(idd);
			  
			 
			  break;
		 }
	
	}

}
