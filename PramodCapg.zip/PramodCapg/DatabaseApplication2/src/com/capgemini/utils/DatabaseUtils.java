package com.capgemini.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtils {
	private Connection connection;
	private static DatabaseUtils object = new DatabaseUtils();

	private DatabaseUtils() {

	}

	public synchronized static DatabaseUtils getInstance() {
		return object;

	}

	public Connection openDatabaseConnection(String username, String password)
			throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl", "seed28", "seed28");
		return connection;
	}

	public Connection openDatabaseConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl", "seed28", "seed28");
		return connection;
	}

	public void closeDatabaseConnection() throws SQLException {
		if (connection != null)
			connection.close();
	}
}
