package exception;

public class Main{
	static String str;

	public static void man(String argc[])
 {
	try{
    int num1=0,num2=0;
    double result=num1/num2;
    System.out.println("result:"+result);
 
    int len =str.length();
    System.out.println("result:"+len);
    }
    catch(ArithmeticException e)
	{
    	  System.out.println("Arithemetic Exception");
    }
	  catch(NullPointerException e)
		{
	    	  System.out.println("String Should have initilised");
	    }
}


	

}