package exception;

import java.io.FileNotFoundException;

public class Main2{
	static String str;
public static void calculation() throws FileNotFoundException
{
boolean flag=true;
if(flag){
	throw new FileNotFoundException();
}
  int num1=0,num2=0;
   if(num2!=0)
	{ 
	 double result=num1/num2;
     System.out.println("result:"+result);
	}
  if(str!=null)
	{int len =str.length();
   System.out.println("result:"+len);
    }
}
  
public static void main(String argc[]) throws FileNotFoundException
{
	try 
	{
	calculation();
	}
	catch(FileNotFoundException e){
		System.out.println("File not Found");
	}
}
}
