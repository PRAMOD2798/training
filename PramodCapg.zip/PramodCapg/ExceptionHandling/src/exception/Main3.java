package exception;

import java.util.Scanner;

public class Main3 {
	static void checkAge(int age) throws AgeException
	{
		if(age>=18&& age<=60){
			System.out.println("Valid Age");
		}
		else
		{
			AgeException a=new AgeException(age);
			throw a;
		}
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
	
		try{
			System.out.println("Enter the Age");
			int age=sc.nextInt();
			checkAge(age);
		}
		catch(AgeException e){
			System.out.println(e);
		}
        catch(Exception e){
        	System.out.println("There Some problem try Again");
		}

		finally{
			System.out.println("Execute Again:");
		}
		
	}

}
