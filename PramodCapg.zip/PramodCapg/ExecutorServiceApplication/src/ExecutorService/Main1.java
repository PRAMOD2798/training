package ExecutorService;

  public class Main1 implements Runnable

{
 public static void main (String  argc[])
 { System.out.println("Executing main Thread");
	 Thread t1=new Thread(new Main1());
	 t1.start();
 }

@Override
public void run() {
	System.out.println("Executing child Thread");
	
}
	  
}
