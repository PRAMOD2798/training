package ExecutorService;



public class Main2 implements Runnable

{
public static void main (String  argc[])
{ System.out.println("Executing main Thread");
	 Thread t1=new Thread(new Main1());
	 t1.start();
	 
	 Runnable runnable=()->System.out.println("Executing Thread Using Lambda");

	 
	 Thread t2=new Thread(runnable);
	 t2.start();
}

@Override
public void run() {
	System.out.println("Executing child Thread");
	
}
	  
}
