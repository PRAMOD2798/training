package ExecutorService;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main3 
{
	public static void main (String argc[])
{		
		Runnable r=()->{
			String  name=Thread.currentThread().getName();
			for(int i=1;i<=5;i++)
			{
				System.out.println(name+" Counting "+i);
			}
			try{
				Thread.sleep(500);
			}catch(InterruptedException e)
			{
				
			}
		};
		
		Runnable r2=()->{
			String  name=Thread.currentThread().getName();
			for(int i=1;i<=5;i++)
			{
				System.out.println(name+" Counting "+i);
			}
			try{
				Thread.sleep(500);
			}catch(InterruptedException e)
			{
				
			}
		};
		Runnable r3=()->{
			String  name=Thread.currentThread().getName();
			for(int i=1;i<=5;i++)
			{
				System.out.println(name+" Counting "+i);
			}
			try{
				Thread.sleep(500);
			}catch(InterruptedException e)
			{
				
			}
		};
		
		ExecutorService service = Executors.newFixedThreadPool(3);
		service.execute(r);
		service.execute(r2);
		service.execute(r3);
		service.shutdown();
		
     }
}
