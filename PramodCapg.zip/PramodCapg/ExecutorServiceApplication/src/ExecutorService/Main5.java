package ExecutorService;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main5 
{
	public void task()
      {
	    String  name=Thread.currentThread().getName();
	     for(int i=1;i<=5;i++)
	    {
		System.out.println(name+" Counting "+i);
	   }
	  try{
		   Thread.sleep(500);
	     }
	  catch(InterruptedException e)
	    {
		
	}
      }
	
		
		public static void main (String argc[])
	      
		
		{	
			/*Main6 obj=new Main6();
			Runnable r1=obj::task;//runnable instance is storing ref. of task method
			Runnable r2=obj::task;
			Runnable r3=obj::task;
			
			r1.run();
			r2.run();
			r3.run();
			*/
			Main5 obj=new Main5();
			Runnable r1=()->obj.task();
			Runnable r2=()->obj.task();
			Runnable r3=()->obj.task();
	    ExecutorService service = Executors.newFixedThreadPool(3);
		service.execute(r1);
		service.execute(r2);
		service.execute(r3);
		service.shutdown();
		
     }
}
