package ExecutorService;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

interface Fun{
	public void fun();
}

interface Fun2{
	public void fun(int x);
}

public class Main6 

{
	public void task()
      {
	  System.out.println("Task method is executing without parameter");
      }
	public static void task(int x)
    {
	  System.out.println("Task method is executing with parameter");
    }
	
		
		public static void main (String argc[])
	      
		{		
			Main6 obj=new Main6();
			Fun f1=obj::task;
			Fun2 f2=Main6::task;
			f1.fun();
			f2.fun(100);
     }
}
