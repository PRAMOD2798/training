package lambda;
@FunctionalInterface
public interface Fun 
{
   public void f();
}
