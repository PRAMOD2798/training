package lambda;

public class FunImpl1 implements Fun
{

	@Override
	public void f() 
	{
		System.out.println("Fun implemented using concreat class");
		
	}
	public static void main(String argc[])
	{
		Fun fun=new FunImpl1();
		fun.f();
		
		Fun fun2=new Fun() {
			
		
			public void f() {
				System.out.println("Fun implemented using annanomous class");
				
			}
		};
		fun2.f();
	}

}
