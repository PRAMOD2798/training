package lambda;

public class Labda2
{
	public static void main(String argc[])
	{
	MaxFinder mf1=(int x,int y) -> {return (x>y)? x:y;};
	System.out.println("Expressiona1 "+mf1.maximum(299,340));
	MaxFinder mf2 =(int x,int y)-> (x>y)?x:y;
	System.out.println("Expressiona2 "+mf2.maximum(567,340));
	MaxFinder mf3 =( x,y)-> (x>y)?x:y;
	System.out.println("Expressiona3 "+mf3.maximum(567,-340));
	} 
	}
	

