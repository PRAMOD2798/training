package lambda;

public class Main1
{
	public static void main(String argc[])
	{
		Fun fun1 = ()->{System.out.println("Hello From Lambda");};
		fun1.f();
		
		Fun fun2=()->System.out.println("Hello from lambda 2");
		fun2.f();
	}
}
