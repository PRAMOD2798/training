package access;
import access1.Foundation;
public class Check 
{
	public static void main(String argc[])
	{
		Foundation f1=new Foundation();
		System.out.println("Default member not Accessible");
		System.out.println("private  Accessible");
		System.out.println("protected  Accessible");
		System.out.println("public  member"+f1.d);
	}
}
