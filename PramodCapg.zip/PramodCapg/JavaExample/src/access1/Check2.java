package access1;

public class Check2 
{
	public static void main(String argc[])
	{
		Foundation f1=new Foundation();
		System.out.println("Default member"+f1.a);
		System.out.println("private member not  Accessible");
		System.out.println("protected member"+f1.c);
		System.out.println("public  member"+f1.d);
	}
}
