package access1;

public class Foundation
{ 
	int a=5;
    private int b=10;
    protected int c=15;
    public int d=20;
 }
