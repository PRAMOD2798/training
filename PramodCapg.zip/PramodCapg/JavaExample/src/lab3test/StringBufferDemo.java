package lab3test;

public class StringBufferDemo 
{
	public static void main(String[] args) 
	{
	
    StringBuffer str=new StringBuffer("Heelo");
     long start=System.currentTimeMillis();
     for(int i=1;i<=100000;i++)
     {
    	 str.append("World");
     }
     
     long end=System.currentTimeMillis();
     System.out.println(str.substring(1,5));
	  System.out.println("milisecond to execute" +(end-start));
    }
}
