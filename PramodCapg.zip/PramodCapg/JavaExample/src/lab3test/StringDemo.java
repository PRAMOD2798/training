package lab3test;

public class StringDemo {

	public static void main(String[] args) 
	{
	
     String str="Heelo";
     long start=System.currentTimeMillis();
     for(int i=1;i<=100000;i++)
     
     str = str +"world";
     
     long end=System.currentTimeMillis();
     System.out.println(str.substring(1,5));
	  System.out.println("milisecond to execute" +(end-start));
    }
}
