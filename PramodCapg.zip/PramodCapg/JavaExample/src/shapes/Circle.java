package shapes;

import java.util.Scanner;

public  class Circle implements Shape 
	{
	public double area()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Radius of circle");
		double radius=s.nextInt();
		
		double ar=PI*radius*radius;
		return ar;
	}
	}
