package shapes;

import java.util.Scanner;

public class MainClass
{
	public static void main(String args[]){
		//Shape s=new Shape();
	//	s.area();
		boolean flag=true;
		Scanner sc=new Scanner(System.in);
		int ch;
		Shape shape1=new Circle();
		Shape shape2=new Rectangle();
		while(flag)
		{
			System.out.println("1.circle");
			System.out.println("2.Rectangle");
			System.out.println("3.Quit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				double e=shape1.area();
				System.out.println("Area of a Circle"+e);
				break;
			case 2:
				double r=shape2.area();
				System.out.println("Area of a Circle"+r);
				break;
			case 3:
				flag=false;
				break;
			default:
				System.out.println("Wrong Choice Please try again");
					
				
			}
		}
	}
}
