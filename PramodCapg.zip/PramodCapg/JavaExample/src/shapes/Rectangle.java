package shapes;

import java.util.Scanner;

public class Rectangle implements Shape{

	public double area() 
	{

		Scanner s=new Scanner(System.in);
		System.out.println("Enter the length:");
		double l=s.nextInt();
		System.out.println("Enter the breadth:");
		double b=s.nextInt();
		double ar=l*b;
		
		return ar; 
	}

}
