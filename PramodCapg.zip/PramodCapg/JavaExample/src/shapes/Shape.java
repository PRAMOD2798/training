package shapes;

public interface Shape

{
	//double PI=3.14;
	public static final double  PI=3.14;
     public double area();
 
	//double area();

	//public abstract double area();
	//public final double area();
  
}
