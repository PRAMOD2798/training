package testlab3;

public class AnotherClass 
{
public static void main(String argc[])
{
	TestClass t1=new TestClass();
	t1=new TestClass();
	t1=new TestClass();
	
	Runtime.getRuntime().gc();
	System.out.println("done");
}
}
