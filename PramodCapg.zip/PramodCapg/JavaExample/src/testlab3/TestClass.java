package testlab3;

public class TestClass
{ 
 
	public void finalize()
	{
	System.out.println("finallize method is called");	
	}

}
