package users;

import java.util.Scanner;

public class Main
{
	 public static int validatepass(String pass)
	 {
		 String ps=" !#$%&'()*+,-./:;<=>?[]^_'{|}~0123456789";
		 String str2[]=pass.split("");
		 for(int i=0;i<str2.length;i++)
		 {
			 if(ps.contains(str2[i]))
				 return 1;
		 }
		 return 0;
	 }
	 
	 public static void validateuser(String username) throws SomeException
	 {
		 if(username.length()<6||username.length()>12||username.indexOf(' ')>0)
			 throw new SomeException();
	 }
	 public static void validatepasss(String password) throws SomeException
	 {
		 if(password.length()<8||password.length()>12||password.indexOf(' ')>0)
			 throw new SomeException();
	 }
	 
 public static void main(String argc[])
 {   
	Scanner sc=new Scanner(System.in);
	String username="",password="";
	UserManager us=new UserManager();
	while(true){
		System.out.println("1.Add user");
		System.out.println("2.Login");
		System.out.println("3.Show");
		int ch=sc.nextInt();
		switch(ch){
		case 1:System.out.println(" Enter Username");
		try{
			username=sc.next();
			validateuser(username);
		     System.out.println(" Enter Password");
		     password=sc.next();
				validatepasss(password);
			}
		catch(SomeException e){
			System.out.println(e);
			break;
		}
		User u=new User(username,password,"user",true);
		us.adduser(u);
		System.out.println("User Successfully added");
		break;
		
		case 2:
		System.out.println(" Enter Username");
		String  loginuser=sc.next();
		if(us.getPassword(loginuser)==null);
		{
			System.out.println("no user exist in Database");
			System.exit(0);
		}
		
		System.out.println(" Enter Password");
		String pas=sc.next();
		if(us.getPassword(loginuser).equals(pas))
		{
			System.out.println("Login Successfully");
		}
		else
		
			System.out.println("wrong Pass");
		System.exit(0);
		break;
		case 3: us.showAllUsers();
		break;
		case 4:System.exit(0);
		break;
		}
	}
	// User user=new User("Pramod","admin@123","Admin",true);
//	 UserManager.adduser(user);
	// UserManager.showAllUsers();
 }
}
