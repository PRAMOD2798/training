package users;

public class SomeException extends Exception 
{
public String toString()
{
	return "IllegalCredintialsException";
}
}
