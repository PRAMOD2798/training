package users;

public class UserManager 
{
	private static  User users[]=new User[100];
	static int i=0;
	static
	{
	users[0]=new User("Aruna","passw@12345","admin",true);
	users[1]=new User("Pramod","passw@12345","user",true);
	users[2]=new User("Lata","passw@12345","user",true);
	
	i=3;
	
	}
	public static void adduser(User user)
	{
		users[i++]=user;
	}
	public static void showAllUsers()
	{
		for(int i=0;i<i;i++)
		{
			System.out.println(users[i]);
		}
	}
	public String getPassword(String username)
	{ for(int j=0;j<i;j++)
	{
		if(users[j].getUsername().equals(username)){
			return users[j].getPassword();
		}
		
	}
		return null;
		
	}
}
