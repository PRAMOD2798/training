class Writer{
	public static void write()
	{
		System.out.println("writing...");
		
	}
}
class Author extends Writer{
	public static void write()
	{
		System.out.println("writing book...");
		
	}
}

public class Programmer extends Author{
	public static void write()
	{
		System.out.println("writing code...");
		
	}
	public static void main(String[] args) {
		Author r=new Programmer();
		r.write();

	}

}
