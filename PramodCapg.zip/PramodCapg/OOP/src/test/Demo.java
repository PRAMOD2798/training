package test;

public class Demo 
{
	  int y=2;
     int x=y+2;
   
     public static void main
     (String atgr[])
     {
    	 Demo d=new Demo();
    	 System.out.println("x= "+d.x+",y= "+d.y);
     }


}
