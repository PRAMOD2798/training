package test;

public class Employee extends Object 
{
private int employeeId;
private String employeeName;
private double employeeSalary;
private static String company="Capgemini";
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) 
{
	this.employeeId = employeeId;
}
public String getEmployeeName() 
{
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public double getEmployeeSalary() {
	return employeeSalary;
}
public void setEmployeeSalary(double employeeSalary) {
	this.employeeSalary = employeeSalary;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
			+ employeeSalary + "]";
}
}
