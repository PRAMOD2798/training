package test;

public class Main {

	public static void main(String[] args) {
		Employee obj=new Employee();
		obj.setEmployeeId(1000);
		obj.setEmployeeName("Pramod");
		obj.setEmployeeSalary(5000);
		System.out.println(obj.toString());
		Employee obj2=new Employee();
		System.out.println(obj2.toString());
	}

}

