package Dao;

import java.util.HashMap;

import Model.Model;

public interface EmployeeDao 
{
  public boolean createEmployee(Model emp);
  public Model readEmployee(int id);
  public HashMap<Integer, Model> showAllEmployee();
}
