package Dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import Model.Model;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private static HashMap<Integer, Model> hm = new HashMap<Integer, Model>();
	
	@Override
	public boolean createEmployee(Model emp) 
	{   
		int i=emp.getEmployeeId();
		Model result = hm.put(i, emp);
		return true;
	}
	
	@Override
	public Model readEmployee(int id) {
		Iterator<Entry<Integer, Model>> itr = hm.entrySet().iterator();
		while (itr.hasNext()) {
			Model obj = itr.next().getValue();
			if (id==obj.getEmployeeId()) {
				return obj;
			}
		}
		return null;

	}

	@Override
	public HashMap<Integer, Model> showAllEmployee() {
		return hm;
	}

}
