package Model;

public class Model {
	private String employeeName;
	private int employeeId;
	private double employeesalary;

	public Model(String employeeName, int employeeId, double employeesalary) {
		super();
		this.employeeName = employeeName;
		this.employeeId = employeeId;
		this.employeesalary = employeesalary;
	}

	public Model() {
		// TODO Auto-generated constructor stub
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public double getEmployeesalary() {
		return employeesalary;
	}

	public void setEmployeesalary(double employeesalary) {
		this.employeesalary = employeesalary;
	}

	@Override
	public String toString() {
		return "Model [employeeName=" + employeeName + ", employeeId=" + employeeId + ", employeesalary="
				+ employeesalary + "]";
	}

}
