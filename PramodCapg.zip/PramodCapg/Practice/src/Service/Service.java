package Service;

import java.util.HashMap;
import java.util.List;

import Model.Model;

public interface Service {
	public boolean addEmployee(Model emp);

	public Model findEmployee(int id);
	
	public HashMap<Integer, Model> showAll();

}
