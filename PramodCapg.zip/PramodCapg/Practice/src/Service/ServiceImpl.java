package Service;

import java.util.HashMap;

import Dao.EmployeeDaoImpl;
import Model.Model;

public class ServiceImpl implements Service {
	EmployeeDaoImpl dao = new EmployeeDaoImpl();

	@Override
	public boolean addEmployee(Model emp) {
		boolean result = dao.createEmployee(emp);
		return result;

	}

	@Override
	public Model findEmployee(int id) {
		Model emp = dao.readEmployee(id);
		return emp;
	}

	@Override
	public HashMap<Integer, Model> showAll() {
		HashMap<Integer, Model> hm = dao.showAllEmployee();
		return hm;
	}

}
