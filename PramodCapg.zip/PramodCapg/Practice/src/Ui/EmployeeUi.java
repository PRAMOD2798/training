package Ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;

import Model.Model;
import Service.Service;
import Service.ServiceImpl;

public class EmployeeUi {

	public static void main(String argc[]) {
		Scanner sc = new Scanner(System.in);

		Service service = new ServiceImpl();

		System.out.println("Welcome");
		boolean flag = true;
		while (flag) {
			System.out.println("1.Add Employee\n2.Find Employee\n3.Show All");
			System.out.println("Enter your choice");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("Enter Employee Name:");
				String str = sc.next();
				System.out.println("Enter Employee id:");
				int id = sc.nextInt();
				System.out.println("Enter Employee Salary:");
				double sal = sc.nextDouble();
				Model emp = new Model(str, id, sal);
				boolean result = service.addEmployee(emp);

				if (result) {
					System.out.println("Employee Added with id " + id);

				} else {
					System.out.println("Some Problem");
				}
				break;

			case 2:
				System.out.println("Enter Employee id:");
				int i = sc.nextInt();
				Model empp = service.findEmployee(i);
				System.out.println(empp);
				break;
			case 3:
				HashMap<Integer, Model> hm = service.showAll();
				Iterator<Entry<Integer, Model>> itr = hm.entrySet().iterator();
				while (itr.hasNext()) {
					System.out.println(itr.next());
				}
				break;
			}
		}
	}
}
