import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Dao.EmployeeDaoImpl;
import Model.Model;

class EmployeeDaoTest {

	EmployeeDaoImpl target;
	
	@BeforeEach
	void setUp() throws Exception {
		target=new EmployeeDaoImpl();
	}

	@AfterEach
	void tearDown() throws Exception {
		target=null;
	}

	@Test
	void testCreateEmployeeShouldReturnTrue() {
		Model mode1=new Model("Pramod Bisht",20,20000);
		boolean result=target.createEmployee(mode1);
		assertTrue(result);
	}
	@Test
	void testReadEmployee()
	{
		Model mode1=target.readEmployee(20);
		assertNotNull(mode1);
	}
	@Test
	void showAllEmployee() {
		HashMap<Integer, Model> hm=new HashMap<>();
		hm=target.showAllEmployee();
		assertNotNull(hm);
   }
}
