package Dao;

import java.util.HashMap;

public interface BookDao
{
	public HashMap<String,Integer> findAllKey();
	public HashMap<String,Integer> findAllValues();
	
	public int  findKeyValue(String str);
}
