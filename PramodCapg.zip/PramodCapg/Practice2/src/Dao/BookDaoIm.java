package Dao;

import java.util.HashMap;

public class BookDaoIm implements  BookDao
{

	@Override
	public HashMap<String, Integer> findAllKey() {
		
		return null;
	}

	@Override
	public HashMap<String, Integer> findAllValues() {
	
		return null;
	}

	@Override
	public int findKeyValue(String str) {
		
		return 0;
	}

}
