package service;

import java.util.HashMap;
import java.util.List;

public interface Service 
{
 
	public HashMap<String,Integer> showAllKey();
	public HashMap<String,Integer> showAllValues();
	
	public int  showKeyValue(String str);
	
}
