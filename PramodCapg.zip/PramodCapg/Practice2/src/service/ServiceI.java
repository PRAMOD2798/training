package service;

import java.util.HashMap;

import Dao.BookDaoIm;

public class ServiceI implements Service
{
    public static HashMap<String ,Integer> hm=new HashMap<>();
	BookDaoIm dao=new BookDaoIm();
	public HashMap<String, Integer> showAllKey()
	{
		HashMap<String, Integer> h=dao.findAllKey();
		return h;
	}

	@Override
	public HashMap<String, Integer> showAllValues() {
		HashMap<String, Integer> hk=dao.findAllValues();
		return hk;
		
	}

	@Override
	public int showKeyValue(String str) {
		int hkv=dao.findKeyValue(str);
		return hkv;
	
	}

}
