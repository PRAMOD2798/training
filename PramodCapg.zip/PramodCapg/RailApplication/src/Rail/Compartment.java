package Rail;

 abstract public class Compartment 
 {
   
 abstract void notice();
 }
   
 

