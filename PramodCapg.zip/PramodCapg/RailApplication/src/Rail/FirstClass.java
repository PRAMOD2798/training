package Rail;

public class FirstClass extends Compartment
{
	 public void notice()
	 {
		 System.out.println("FirstClass coach");
	 }
}
