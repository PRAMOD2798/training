package Rail;

public class Luggage extends Compartment
{
	 public void notice()
	 {
		 System.out.println("Luggage coach");
	 }
}
