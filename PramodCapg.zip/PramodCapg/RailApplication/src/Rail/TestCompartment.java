package Rail;

public class TestCompartment
{
    public static void main(String argc[])
    {
    	
    	Compartment c1;
    	  Compartment compartment[]=new  Compartment[10];
    	   General g=new General();
    	   Ladies l=new Ladies();
    	   FirstClass fs=new FirstClass();
    	   Luggage tr= new Luggage();
    	   
    	   for(int i=0;i<compartment.length;i++)
    	   {
    		   int random=(int)(Math.random()*4);
    		   switch(random)
    		   {
    		   		case 1:
    		   		compartment[i]=g;
    		   		break;
    		   		case 2:    
    		   		compartment[i]=l;
    		   		break;
    		   		case 3:
    		   		compartment[i]=fs;
    		   		break;
    		   		case 4:    
    		   		compartment[i]=tr;
    		   		break;
    		   		default:
    			    compartment[i]=g;  
    		  
    	         }
    	  }
    	   for( Compartment c: compartment){
    		   c.notice();
    	   }
    	
    }
}
