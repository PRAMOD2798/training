package interfaces;

public interface I1
{
	public  void f1();
	public default void f2()
	{
		System.out.println("I1:f2()");
	}
	public static void f3(){
		System.out.println("I1:f3()");
	}
}
