package interfaces;

class C1 implements I1
{
	public void f1()
	{
		System.out.println("c1:f1()");
	}
	public void f2()
	{
		System.out.println("c1:f2()");
	}
}
public class Main 
{
	
   public static void main(String argc[])
   {
	   I1 obj=new C1();
	   obj.f1();
	   obj.f2();
	   I1.f3();
   }
}
