package stream;

import java.util.ArrayList;
import java.util.List;

public class Main 
{
	public static void main(String argc[])
	{
		List<String> list=new ArrayList<String>();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		list.add("E");
		
		
		list.stream();
		list.stream().forEach((String str)->{System.out.println(str);});
		
		list.stream().forEach(str->System.out.println(str));
		
	}
}
