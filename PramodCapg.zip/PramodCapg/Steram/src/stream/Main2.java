package stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main2 
{
  public static void main(String argc[])
  {
	  List<String> list=new ArrayList<String>();
	  list.add("Capgemini");
	  list.add("Syntel");
	  list.add("LNT");
	  list.add("JP Morgen");
	  list.add("TCS");
	  list.add("Google");
	  list.add("Facebook");
	  list.add("Tweeter");
	  long result=list.stream().count();
	  System.out.println("List of companies: "+result);
	  list.stream().filter((String s)->{return true; });
	  list.stream().filter((String s)->{if (s.length()>4){return true;}
	  else {return false;}});
	  
	  
	  list.stream().filter(s ->s.length()>4)
	  .forEach(System.out::println);
	  Set<String> set= list.stream().filter(s->s.startsWith("T"))
			   .collect(Collectors.toSet());
	  System.out.println(set);
	  
  } 
}
