package student;

public class Main
{
public static void main(String args[])
{
	Student[] students=new Student[5];
	Student s1=new Student(100,"Pramod",8728348,"Java",5000);
	Student s2=new Student(101,"Rahul",87256,"Python",5000);
	Student s3=new Student(106,"Manish",8728348,"C",5000);
	Student s4=new Student(108,"Pb",8728348,"C++",5000);
	Student s5=new Student(107,"Mohit",8728348,"Java",5000);
	students[0]=s1;
	students[1]=s2;
	students[2]=s3;
	students[3]=s4;
	students[4]=s5;
	displayStudentByCourse(students,"Java");
	
	
	
}

private static void displayStudentByCourse( Student s[],String course) 
{
	/*for(int i=0;i<s.length;i++)
	{
		if(s[i].getCourse().equals(course))
		{
			s[i].display();
		}
	}
	*/
	for(Student t:s)
	{
		if(t.getCourse().equals(course))
		{
			t.display();
		}
	}
	
}
}
