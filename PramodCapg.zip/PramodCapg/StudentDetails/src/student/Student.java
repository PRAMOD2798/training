package student;

public class Student 
{
	private int studentId;
	private String name;
	private int contactNo;
	private String course;
	private double fees;

	 public Student(int studentId,String name,int contactNo, String course,double fees )
	 {
		 this.studentId=studentId;
		 this.name=name;
		 this.contactNo=contactNo;
		 this.course=course;
		 this.fees=fees;
		 
		 
	 }
	 public double getFees()
	 {
		 return fees;
	 }
	 public String getCourse()
	 {
		 return course;
	 }
	 public void display()
	 
	 {
		System.out.println("student StudentId\t"+studentId); 
		System.out.println("student Name\t"+name); 
		System.out.println("student contactNo\t"+contactNo); 
		System.out.println("student course\t"+course); 
		System.out.println("student Fees\t"+fees); 
		
	 }
	

}
