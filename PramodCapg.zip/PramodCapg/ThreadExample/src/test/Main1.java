package test;

public class Main1 
{
  public static void main(String argc[])
  {
	  System.out.println(" How Many thread this program contain:");
	  Thread t=Thread.currentThread();
	  String threadname=t.getName();
	  System.out.println("Name of the thread:"+threadname);
	  math1();
	  
  }

private static void math1() {
System.out.println("Name of the thread:"+Thread.currentThread().getName());
	
}
}
