package test;
class Thread1 extends Thread
{
	public void run()
	{
		System.out.println("Name:"+Thread.currentThread().getName());
	}
}
public class Main2 {
public static void main(String argc[])
{
	//Thread t1=new Thread();
	//t1.run();
	System.out.println("Start");
	Thread1 t=new Thread1();
	//t.run();
	t.start();
    t.run();
	System.out.println("End");
}
}
