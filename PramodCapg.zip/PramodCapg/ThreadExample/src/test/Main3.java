package test;
class Thread2 implements Runnable
{

	
	public void run() 
	{
		System.out.println("Name:"+Thread.currentThread().getName());
		
	}
	
}
public class Main3 
{
public static void main(String argc[]){
	Thread t1=new Thread(new Thread2());//worker thread
	t1.getState();	
	System.out.println("state "+t1.getState());
	t1.setName("child thread");
	t1.start();
	System.out.println("state "+t1.getState());
	try{
	Thread.sleep(50);
	}
	catch(InterruptedException e){
		System.out.println("Thread is some tecnical issue");
	}
	System.out.println("End of the main");
}
}
