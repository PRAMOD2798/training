package test;

class Print

{

   public  void display(String msg)

   {
	   synchronized(this){
		      System.out.print ("["+msg);

		      try

		      {

		         Thread.sleep(500);

		      }

		      catch(InterruptedException e)

		      {

		         e.printStackTrace();

		      }

		      System.out.println ("]");
	   }


   }

}

class PrintThread extends Thread

{

     private String msg;

     private Print print;

     PrintThread (Print print,String str)

     {

     this.print = print;

     msg = str;

     start();

     }

     public void run()

     {  

      print.display(msg);

     }

}

public class SyncBlockDemo

{

    public static void main (String[] args)

    {

    Print obj = new Print();

       PrintThread pt1  = new PrintThread(obj, "Hello");

       PrintThread pt2 = new PrintThread (obj,"Synchronized");

       PrintThread pt3 = new PrintThread(obj, "World");

    }

}

 

