package com.capgemini;

public interface Calcy 
{
  public int add(int num,int num2) throws IllegalArgumentException;
  public int sub(int num,int num2) throws IllegalArgumentException;
  
}
