package com.capgemini;

public class CalcyImpl implements Calcy
{

	@Override
	public int add(int num, int num2) throws IllegalArgumentException {
		if(num<0||num2<0)
		{
			throw new IllegalArgumentException("Expecting positive numbers");
		}
		return num+num2;
	}

	
	public int sub(int num, int num2) throws IllegalArgumentException {
		if(num<0||num2<0)
		{
			throw new IllegalArgumentException("Expecting positive numbers");
		}
		else if(num<num2)
		{
			throw new IllegalArgumentException("Number1 can not be smaller than number2");
		}
		return num2-num;
}}
