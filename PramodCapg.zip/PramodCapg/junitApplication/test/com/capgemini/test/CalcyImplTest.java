package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.CalcyImpl;

class CalcyImplTest {
   
    
    private CalcyImpl target;
	@BeforeEach
    public void beforeEach()
    {
    	 target = new CalcyImpl();
    }
	
	@AfterEach
	public void afterEach()
	{
		target=null;
	}
    
	@Test
	void testAddShouldReturnSumOfNumbers()
	{
		int result=target.add(1000,2000);
		assertEquals(3000, result);
		assertEquals(3500, target.add(3000, 500));
	}
	@Test
	public void testAddShouldThrowIllegalArgumentExceptionForFirstParameter()
	{
		assertThrows(IllegalArgumentException.class,()->{
			target.add(-1000, 2000);
		});
		assertThrows(IllegalArgumentException.class,()->target.add(-100, 200));
	}

 
}
