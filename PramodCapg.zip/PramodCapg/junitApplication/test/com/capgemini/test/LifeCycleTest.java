package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.AfterClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LifeCycleTest
{
     @BeforeEach
     public void setUp()
     {
    	 System.out.println("I am going to execute Before Each test case");
     }
     
	@AfterEach
	 public void setDown()
    {
   	 System.out.println("I am going to execute After Each test case");
    }
	
	@BeforeAll
	public static void beforeAll() {
		System.out.println("I am going to execute BeforeAll  test case");
	}
	@AfterAll
	public static void afterAll() {
		System.out.println("I am going to execute afterAll  test case");
	}
	
	@Test
	void testAdd() {
		System.out.println("test add");
	}

	@Test
	void testSub() {
		System.out.println("test sub");
	}

}
