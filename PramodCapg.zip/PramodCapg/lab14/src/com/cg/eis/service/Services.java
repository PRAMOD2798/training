package com.cg.eis.service;

public interface Services 
{
  public String employeeService(Employee employee);
}
