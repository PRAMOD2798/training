package ProductModel;

public class ProductModel 
{
	private String productName;
	private String productCategory;
	private int price;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public ProductModel(String productName, String productCategory, int price) {
		super();
		this.productName = productName;
		this.productCategory = productCategory;
		this.price = price;
	}
	@Override
	public String toString() {
		return "ProductModel [productName=" + productName + ", productCategory=" + productCategory + ", price=" + price
				+ "]";
	}
	
}
