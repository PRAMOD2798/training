package com.cg.productUi;

import java.util.Scanner;

import com.cg.productmgmt.service.ProductService;

public class ProductUi 
{
  
	public static void main(String argc[])
	{
		Scanner sc=new Scanner(System.in);
		ProductService service=new ProductService();
		System.out.println("*********Welcome*********");
		 boolean flag=true;
		 
		 while(flag)
		 {
			 System.out.println("1.Update Product Price\2.Exit");
			 
			 System.out.println("Emter your choice");
			 int n=sc.nextInt();
			 switch(n)
			 {
			 case 1:
				 System.out.println("Enter Product Name:");
				 String str=sc.next();
				 System.out.println("Enter New Price");
				 int price=sc.nextInt();
				 service.updateProducts(str, price);
				
				 
			 }
			 
		 }
		
	}
}
