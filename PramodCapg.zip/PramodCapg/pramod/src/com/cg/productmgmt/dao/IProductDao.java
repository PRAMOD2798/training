package com.cg.productmgmt.dao;

import java.util.Map;



public interface IProductDao 
{
	 public Map<String,Integer> updateProducts(String category,int hike);
	
}
