package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ProductDao implements IProductDao
{
	 static Map<String,Integer> salesDetails;
	static Map<String ,String> productDetails;
	static
	{
		productDetails=new HashMap<>();
		productDetails.put("lux","soap");
		productDetails.put("colgate","paste");
		productDetails.put("pears","soap");
		productDetails.put("sony","electronics");
		productDetails.put("samsung","electronics");
		productDetails.put("facepack","cosmatics");
		productDetails.put("facecream","cosmatics");
		
		
	//second hashmap for product name as key and product price as value value
	 
		
		 salesDetails=new HashMap<>();
		 salesDetails.put("lux",100);
		 salesDetails.put("colgate",50);
		 salesDetails.put("pears",70);
		 salesDetails.put("sony",10000);
		 salesDetails.put("samsung",23000);
		 salesDetails.put("facepack",100);
		 salesDetails.put("facecream",60);
		
	}
	static Map<String, String> method1()
	{
		return productDetails;
	}
	static Map<String,Integer> method2()
	{
		return  salesDetails;
	}
	public Map<String, Integer> updateProducts(String category, int hike) 
	{
		Set<Entry<String, Integer>> map=salesDetails.entrySet();
		Iterator<Entry<String, Integer>> itr=map.iterator();
		
		return null;
	}

}
