package com.cg.productmgmt.service;

import java.util.Map;

public interface IProductService 
{
     public Map<String,Integer> updateProducts(String category,int hike) ;
     public boolean validateHike(int hike);
     public boolean validatecategory(String prodCat) ;
}
