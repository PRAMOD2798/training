package com.cg.productmgmt.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;

public class ProductService implements IProductService
{
     IProductDao dao=new ProductDao(); 
  
    
	
	public Map<String, Integer> updateProducts(String category, int hike) {
		Map<String, Integer> hm=dao.updateProducts(category, hike);
		return hm;
	}

	@Override
	public boolean validateHike(int hike)
	{
	    
		return false;
	}

	@Override
	public boolean validatecategory(String prodCat) {
		
		return false;
	}



}
