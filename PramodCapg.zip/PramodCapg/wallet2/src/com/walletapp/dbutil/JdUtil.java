package com.walletapp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdUtil {
	private static Connection con;
	private static JdUtil object = new JdUtil();

	private JdUtil() {

	}

	public synchronized static JdUtil getInstance() {
		return object;
	}

	public void closeDatabaseConnection() throws SQLException {

		if (con != null)
			con.close();
	}

	public Connection openDatabaseConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl", "seed31", "seed31");
		return con;
	}
}
