export class Address{
addressId:number;
fullName:string;
mobileNumber:number;
pincode:number;
houseNo:string;
locality:string;
landmark:string;
city:string;



}