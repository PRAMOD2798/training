export enum DiscountCodeType{
    PROMO,COUPON
}