import { Component, OnInit } from '@angular/core';

import { AdminpageComponent } from '../adminpage/adminpage.component';
import { AdminServiceService } from '../admin-service.service';
import { Merchant } from '../merchant';

@Component({
  selector: 'app-sign-up-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class SignUpMerchantComponent implements OnInit {
  merchant:Merchant;
  constructor(private adminService:AdminServiceService) { }
  merchId:number;
  ngOnInit() {
  }
  addMerchant(fname,email,phone,password,address,commission ){
  
  this.merchant.merchantName=fname;
  this.merchant.email=email;
  this.merchant.mobileNumber=phone;
  this.merchant.password=password;
  this.merchant.address=address;
  this.merchant.commissionPercent=commission;
  
 
  this.adminService.addMerchant(this.merchant).subscribe(merchant=> {
    this.merchId=merchant.merchatId;
   
  });
 }
}
