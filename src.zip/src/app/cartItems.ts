export class CartItems{
    cartId:number;
    cartQuantity:number;
}