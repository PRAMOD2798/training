import { OrderedItem } from './ordered-item';
import { DiscountCodeType } from './DiscountCodeType';

export class DiscountCode {
    name:string;
    value:number;
    type:DiscountCodeType;
    startDate:Date;
    endDate:Date;
    minimumAmount:number;
}
