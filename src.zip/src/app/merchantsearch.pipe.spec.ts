import { MerchantsearchPipe } from './merchantsearch.pipe';

describe('MerchantsearchPipe', () => {
  it('create an instance', () => {
    const pipe = new MerchantsearchPipe();
    expect(pipe).toBeTruthy();
  });
});
