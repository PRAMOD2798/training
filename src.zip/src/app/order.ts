import { OrderedItem } from './ordered-item';


export class Order{
    orderId:number;
    orderedDate:Date;
    items:OrderedItem[];
}