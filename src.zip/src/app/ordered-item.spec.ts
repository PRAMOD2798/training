import { OrderedItem } from './ordered-item';

describe('OrderedItem', () => {
  it('should create an instance', () => {
    expect(new OrderedItem()).toBeTruthy();
  });
});
