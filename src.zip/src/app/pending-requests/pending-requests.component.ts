import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Merchant } from '../Merchant';
import { Router } from '@angular/router';
import { Address } from '../Address';

@Component({
  selector: 'app-pending-requests',
  templateUrl: './pending-requests.component.html',
  styleUrls: ['./pending-requests.component.css']
})
export class PendingRequestsComponent implements OnInit {

  merchant: Merchant[];
  
  merch: Merchant;
  
  

  constructor(private router: Router, private httpClientService: AdminServiceService) { }

  ngOnInit() {
    

    this.httpClientService.pendingRequests().subscribe(
      data => {
        this.merchant = data;
      }
    )

  }

  acceptMerchant(merchantId:number) {
    this.httpClientService.changeStatus(merchantId,"APPROVED").subscribe(
      (data) => { this.ngOnInit() 
      console.log(data)}
    );

  }

  denyMerchant(merchantId: number) {
    this.httpClientService.changeStatus(merchantId,"FAILED").subscribe(
      (data) => { this.ngOnInit()
        console.log(data) })
  }



}
