import { Component, OnInit } from '@angular/core';
// import { Business } from '../business';
import { BusinessService } from '../business.service';
import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';
import { Order } from '../order';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  orderId="";
  merchantId="";
  category="";
  order:Order;
  orderItems:OrderedItem[];
  
  selectedStatus:string;
  constructor(private businessService: AdminServiceService) {
    
   }

  

  ngOnInit() {
    this.businessService.display().subscribe( (businessli) => 
    {
      this.order = (businessli);
      console.log(this.order);
      // console.log("Testing")
    }
  )
    
  }

}
