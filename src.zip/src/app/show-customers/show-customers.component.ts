import { Component, OnInit } from '@angular/core';

import { AdminServiceService } from '../admin-service.service';
import { Customer } from '../Customer';


@Component({
  selector: 'app-show-customers',
  templateUrl: './show-customers.component.html',
  styleUrls: ['./show-customers.component.css']
})


export class ShowCustomersComponent {
customer:Customer[];
status:boolean=false;
  constructor( private httpClientService:AdminServiceService) { }

  onSubmit() {
    // this.httpClientService.showCustomers().subscribe(
    //   data =>{this.customer = data;}
    //  );
    console.log("Success");
     this.status=true;

  }

}
