import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowMerchantsComponent } from './show-merchants.component';

describe('ShowMerchantsComponent', () => {
  let component: ShowMerchantsComponent;
  let fixture: ComponentFixture<ShowMerchantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowMerchantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowMerchantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
